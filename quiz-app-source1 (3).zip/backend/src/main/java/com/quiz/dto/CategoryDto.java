package com.quiz.dto;

import lombok.Data;
import lombok.AllArgsConstructor;

@Data
@AllArgsConstructor
public class CategoryDto {
    private Long id;
    private String name;
    private int totalQuestions;
    private int correctlyAnswered;
}
