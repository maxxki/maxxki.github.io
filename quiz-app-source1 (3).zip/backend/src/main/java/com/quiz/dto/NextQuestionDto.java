package com.quiz.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class NextQuestionDto {
    private Long questionId;
    private String questionText;
    private List<String> answerOptions;
    private boolean allAnswered;
    private String message;

    public static NextQuestionDto completed(String message) {
        NextQuestionDto dto = new NextQuestionDto();
        dto.setAllAnswered(true);
        dto.setMessage(message);
        return dto;
    }
}
