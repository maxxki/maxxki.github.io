package com.quiz.dto;

public class AnswerResult {
    private boolean correct;
    private int correctAnswerIndex;
    private int categoryProgress;  // NEU: Fortschritt in Prozent (0-100)
    
    // Konstruktor
    public AnswerResult(boolean correct, int correctAnswerIndex, int categoryProgress) {
        this.correct = correct;
        this.correctAnswerIndex = correctAnswerIndex;
        this.categoryProgress = categoryProgress;
    }
    
    // Getter und Setter
    public boolean isCorrect() { return correct; }
    public void setCorrect(boolean correct) { this.correct = correct; }
    
    public int getCorrectAnswerIndex() { return correctAnswerIndex; }
    public void setCorrectAnswerIndex(int correctAnswerIndex) {
        this.correctAnswerIndex = correctAnswerIndex;
    }
    
    public int getCategoryProgress() { return categoryProgress; }
    public void setCategoryProgress(int categoryProgress) {
        this.categoryProgress = categoryProgress;
    }
}
