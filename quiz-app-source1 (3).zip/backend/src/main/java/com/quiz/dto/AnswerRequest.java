package com.quiz.dto;

import lombok.Data;

@Data
public class AnswerRequest {
    private int selectedAnswerIndex;
}
