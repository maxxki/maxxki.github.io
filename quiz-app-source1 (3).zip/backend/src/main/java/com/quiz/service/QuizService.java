package com.quiz.service;

import com.quiz.dto.*;
import com.quiz.model.*;
import com.quiz.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuizService {

    private static final Long USER_ID = 1L;

    private final CategoryRepository categoryRepository;
    private final QuestionRepository questionRepository;
    private final UserAnswerRepository userAnswerRepository;

    public List<CategoryDto> getAllCategories() {
        List<Category> categories = categoryRepository.findAll();

        // Alle korrekt beantworteten Fragen des Users laden
        Set<Long> correctlyAnsweredIds = userAnswerRepository
                .findByUserIdAndCorrect(USER_ID, true)
                .stream()
                .map(ua -> ua.getQuestion().getId())
                .collect(Collectors.toSet());

        return categories.stream().map(cat -> {
            List<Question> questions = questionRepository.findByCategoryId(cat.getId());
            int total = questions.size();
            int correct = (int) questions.stream()
                    .filter(q -> correctlyAnsweredIds.contains(q.getId()))
                    .count();
            return new CategoryDto(cat.getId(), cat.getName(), total, correct);
        }).collect(Collectors.toList());
    }

    public NextQuestionDto getNextQuestion(Long categoryId) {
        List<Question> questions = questionRepository.findByCategoryId(categoryId);

        Set<Long> correctlyAnsweredIds = userAnswerRepository
                .findByUserIdAndCorrect(USER_ID, true)
                .stream()
                .map(ua -> ua.getQuestion().getId())
                .collect(Collectors.toSet());

        Optional<Question> nextQuestion = questions.stream()
                .filter(q -> !correctlyAnsweredIds.contains(q.getId()))
                .findFirst();

        if (nextQuestion.isEmpty()) {
            return NextQuestionDto.completed("Glückwunsch! Du hast alle Fragen dieser Kategorie richtig beantwortet! 🎉");
        }

        Question q = nextQuestion.get();
        NextQuestionDto dto = new NextQuestionDto();
        dto.setQuestionId(q.getId());
        dto.setQuestionText(q.getQuestionText());
        dto.setAnswerOptions(List.of(q.getOption0(), q.getOption1(), q.getOption2(), q.getOption3()));
        dto.setAllAnswered(false);
        return dto;
    }

    public AnswerResult submitAnswer(Long questionId, int selectedIndex) {
        Question question = questionRepository.findById(questionId)
                .orElseThrow(() -> new RuntimeException("Frage nicht gefunden"));

        boolean isCorrect = question.getCorrectOptionIndex() == selectedIndex;

        // Nur speichern wenn noch nicht korrekt beantwortet (korrekte Antwort bleibt gespeichert)
        Optional<UserAnswer> existing = userAnswerRepository.findByUserIdAndQuestionId(USER_ID, questionId);
        if (existing.isEmpty() || (!existing.get().isCorrect() && isCorrect)) {
            UserAnswer ua = existing.orElse(new UserAnswer());
            ua.setUserId(USER_ID);
            ua.setQuestion(question);
            ua.setCorrect(isCorrect);
            userAnswerRepository.save(ua);
        }

        // NEU: Fortschritt für diese Kategorie berechnen
        Long categoryId = question.getCategory().getId(); // Annahme: Question hat eine Category-Referenz
        int categoryProgress = calculateCategoryProgress(categoryId);

        return new AnswerResult(isCorrect, question.getCorrectOptionIndex(), categoryProgress);
    }

    // NEU: Hilfsmethode zur Berechnung des Kategorie-Fortschritts
    private int calculateCategoryProgress(Long categoryId) {
        // Alle Fragen der Kategorie
        List<Question> questions = questionRepository.findByCategoryId(categoryId);
        int totalQuestions = questions.size();
        
        if (totalQuestions == 0) {
            return 0;
        }

        // Alle korrekt beantworteten Fragen in dieser Kategorie
        Set<Long> correctlyAnsweredIds = userAnswerRepository
                .findByUserIdAndCorrect(USER_ID, true)
                .stream()
                .map(ua -> ua.getQuestion().getId())
                .collect(Collectors.toSet());

        long correctlyAnsweredInCategory = questions.stream()
                .filter(q -> correctlyAnsweredIds.contains(q.getId()))
                .count();

        // Prozent berechnen (0-100)
        return (int) ((correctlyAnsweredInCategory * 100) / totalQuestions);
    }
}
