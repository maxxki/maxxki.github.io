package com.quiz.controller;

import com.quiz.dto.*;
import com.quiz.service.QuizService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class QuizController {

    private final QuizService quizService;

    @GetMapping("/categories")
    public ResponseEntity<List<CategoryDto>> getCategories() {
        return ResponseEntity.ok(quizService.getAllCategories());
    }

    @GetMapping("/categories/{id}/next-question")
    public ResponseEntity<NextQuestionDto> getNextQuestion(@PathVariable Long id) {
        return ResponseEntity.ok(quizService.getNextQuestion(id));
    }

    @PostMapping("/questions/{id}/answer")
    public ResponseEntity<AnswerResult> submitAnswer(
            @PathVariable Long id,
            @RequestBody AnswerRequest request) {
        return ResponseEntity.ok(quizService.submitAnswer(id, request.getSelectedAnswerIndex()));
    }
}
