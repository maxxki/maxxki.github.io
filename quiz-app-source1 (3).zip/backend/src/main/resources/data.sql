INSERT INTO category (id, name) VALUES (1, 'Seezeichen & Feuer');
INSERT INTO category (id, name) VALUES (2, 'Fahrregeln');
INSERT INTO category (id, name) VALUES (3, 'Knotenkunde');

-- Kategorie 1: Seezeichen & Feuer (6 Fragen)
INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (1, 'Was bedeutet ein rotes Tonnenzeichen?', 'Backbordseite der Fahrrinne', 'Steuerbordseite der Fahrrinne', 'Sperrgebiet', 'Ankergrund', 0, 1);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (2, 'Welche Farbe hat die Steuerbordseite der Fahrrinne?', 'Rot', 'Gelb', 'Grün', 'Weiß', 2, 1);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (3, 'Was bedeutet ein gelbes Kreuzzeichen auf einer Tonne?', 'Trennzeichen', 'Gefahrenstelle', 'Ankerverbot', 'Wendestelle', 0, 1);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (4, 'Welche Farbe hat eine Gefahrenzeichen-Tonne (Kardinaltonne Nord)?', 'Rot-Weiß gestreift', 'Schwarz-Gelb mit schwarzen Kegeln oben', 'Grün-Rot gestreift', 'Gelb-Schwarz mit gelben Kegeln', 1, 1);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (5, 'Was kennzeichnet ein weißes Blitzfeuer mit rotem Sektor?', 'Sicheres Fahrwasser im weißen Sektor', 'Gefährliches Gebiet im weißen Sektor', 'Ankerzone im roten Sektor', 'Hafeneinfahrt im roten Sektor', 0, 1);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (6, 'Was bedeutet eine Tonne mit Kreuz-Toppzeichen?', 'Sperrgebiet – Durchfahrt verboten', 'Ankerplatz', 'Wendestelle', 'Fährverbindung', 0, 1);

-- Kategorie 2: Fahrregeln (7 Fragen)
INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (7, 'Wer hat Vorfahrt auf Binnenwasserstraßen?', 'Segelboot', 'Motorboot', 'Berufsschifffahrt', 'Sportboot', 2, 2);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (8, 'Was bedeutet "Backbord"?', 'Rechte Seite in Fahrtrichtung', 'Linke Seite in Fahrtrichtung', 'Vorschiff', 'Heckseite', 1, 2);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (9, 'Welches Schallsignal bedeutet "Ich biege nach Steuerbord ab"?', 'Zwei kurze Töne', 'Ein langer Ton', 'Ein kurzer Ton', 'Drei kurze Töne', 2, 2);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (10, 'Was gilt beim Begegnen auf einem Fluss in der Regel?', 'Jeder weicht nach Steuerbord aus', 'Talfahrer weicht dem Bergfahrer aus', 'Bergfahrer weicht dem Talfahrer aus', 'Das schnellere Schiff hat Vorfahrt', 2, 2);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (11, 'Welche Lichter muss ein Motorboot unter 7 m nachts führen?', 'Nur ein weißes Rundumlicht', 'Seitenlichter + Hecklicht', 'Topplicht + Seitenlichter + Hecklicht', 'Ein weißes Rundumlicht oder Seitenlichter + Hecklicht', 3, 2);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (12, 'Was bedeutet das Schallsignal „drei kurze Töne"?', 'Ich fahre rückwärts', 'Ich biege nach Backbord ab', 'Ich biege nach Steuerbord ab', 'Achtung – Gefahr', 0, 2);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (13, 'Wie viel Abstand muss beim Überholen mindestens eingehalten werden?', '5 Meter', '10 Meter', 'Ausreichend sicherer Abstand je nach Situation', '50 Meter', 2, 2);

-- Kategorie 3: Knotenkunde (5 Fragen)
INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (14, 'Wofür verwendet man einen Palstek?', 'Festmachen an einer Boje', 'Zwei Leinen verbinden', 'Leine verkürzen', 'Anker befestigen', 0, 3);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (15, 'Welcher Knoten eignet sich zum Verbinden zweier gleich dicker Leinen?', 'Palstek', 'Kreuzknoten', 'Achtknoten', 'Webeleinenstek', 1, 3);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (16, 'Wofür wird ein Achtknoten hauptsächlich verwendet?', 'Als Stopper am Leinenende', 'Zum Festmachen am Poller', 'Zum Verbinden zweier Leinen', 'Als Schleppknoten', 0, 3);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (17, 'Welcher Knoten wird zum Festmachen an einem Poller oder Ring verwendet?', 'Kreuzknoten', 'Webeleinenstek', 'Achtknoten', 'Palstek', 1, 3);

INSERT INTO question (id, question_text, option0, option1, option2, option3, correct_option_index, category_id)
VALUES (18, 'Was ist ein Vorteil des Palsteks gegenüber anderen Festmacheknoten?', 'Er lässt sich auch unter Last gut lösen', 'Er zieht sich unter Last nicht zu', 'Er ist der schnellste Knoten', 'Er kann nasse Leinen verbinden', 1, 3);
