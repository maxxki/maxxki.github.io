BootsschuleX Quiz – Aufgabe 1

@author: Maximilian Kiefer
@github: https://maxxki.github.io



Mini-Quiz-Webanwendung mit Spring Boot Backend und Next.js Frontend, SpringBoot, Hibernate, MariaDB


 Projektstruktur

```
quiz-project/
├── backend/          # Spring Boot + Hibernate + MariaDB
├── frontend/         # Next.js + TypeScript + Tailwind CSS
├── docker-compose.yml
└── README.md
```


 Installation (falls nicht vorhanden)
```bash
 Termux
pkg install mariadb

 Ubuntu/Debian
sudo apt install mariadb-server

 macOS
brew install mariadb
```

MariaDB starten

 Im Hintergrund starten
mysqld_safe &

 Status prüfen
mysqladmin -u root -p status

In MariaDB einloggen
mysql -u root -p


Nützliche Befehle

Stoppen:
mysqladmin -u root -p shutdown

 Prozess prüfen
ps aux | grep mysql

 Auf Fehler prüfen
tail -f /data/data/com.termux/files/usr/var/log/mysql/error.log


Die Datenbank ist dann auf `localhost:3306` erreichbar:
- Datenbank: `quizdb`
- Benutzer: `quizuser`
- Passwort: `quizpassword`



Backend starten

cd backend
./gradlew bootRun

Das Backend läuft dann auf **http://localhost:8080**.


API-Endpunkte

| Methode | Pfad | Beschreibung |
|--------|------|-------------|
| GET | `/api/categories` | Alle Kategorien mit Fortschritt |
| GET | `/api/categories/{id}/next-question` | Nächste unbeantwortete Frage |
| POST | `/api/questions/{id}/answer` | Antwort einreichen |



Frontend starten (Next.js)
cd frontend
npm install
npm run dev


Das Frontend läuft auf **http://localhost:3000**.

