// questions.js – Angepasst für das BootsschuleX Backend (Aufgabe 1)
// Die statische questions-Array wurde durch API-Calls ersetzt.
// Die Fragen kommen nun aus der Spring Boot REST-API (via MariaDB Seed-Daten).

// --- KONFIGURATION & ELEMENTE ---
const API_BASE = "http://localhost:8080/api";
const CATEGORY_ID = 1; // Kann dynamisch gesetzt werden (z.B. aus URL-Parameter)

const quiz_box = document.querySelector(".quiz_box");
const result_box = document.querySelector(".result_box");
const option_list = document.querySelector(".option_list");
const next_btn = document.querySelector("footer .next_btn");
const que_text = document.querySelector(".que_text");
const bottom_ques_counter = document.querySelector("footer .total_que");

let currentQuestion = null;

// --- INITIALER START ---
window.onload = () => {
  loadNextQuestion();
};

// --- LOGIK: NÄCHSTE FRAGE LADEN ---
// Ersetzt das statische Array-Lookup. Ruft GET /api/categories/{id}/next-question auf.
async function loadNextQuestion() {
  try {
    const response = await fetch(
      `${API_BASE}/categories/${CATEGORY_ID}/next-question`
    );
    const data = await response.json();

    // Backend signalisiert: alle Fragen wurden korrekt beantwortet
    if (data.allAnswered) {
      showResult(data.message || "Kategorie erfolgreich gemeistert! ⚓");
      return;
    }

    currentQuestion = data; // Speichern für die Antwort-Prüfung
    renderQuestionUI(data);
    updateProgress(); // Fortschrittsbalken/Zähler aktualisieren
  } catch (error) {
    console.error("Fehler beim Laden der Frage:", error);
    que_text.innerHTML =
      "<span>Fehler beim Laden der Daten. Ist das Backend aktiv?</span>";
  }
}

// --- UI: FRAGE RENDERN ---
// Ersetzt die statische Anzeige aus dem Array.
// data.answerOptions entspricht den options[] aus dem alten Array.
// data.questionText entspricht question aus dem alten Array.
function renderQuestionUI(data) {
  que_text.innerHTML = `<span>${data.questionText}</span>`;

  // Optionen aus dem Backend-Array generieren (war vorher options[])
  option_list.innerHTML = data.answerOptions
    .map(
      (opt, index) =>
        `<div class="option" onclick="optionSelected(${index})"><span>${opt}</span></div>`
    )
    .join("");

  next_btn.classList.remove("show");
}

// --- LOGIK: ANTWORT SENDEN & CHECKEN ---
// Ersetzt den alten Vergleich: if (userAns == questions[queCount].answer)
// Jetzt wird der Index per POST /api/questions/{id}/answer ans Backend gesendet.
async function optionSelected(index) {
  const allOptions = option_list.children;

  try {
    const response = await fetch(
      `${API_BASE}/questions/${currentQuestion.questionId}/answer`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ selectedAnswerIndex: index }),
      }
    );
    const result = await response.json();

    // Visuelles Feedback (⚓ für Richtig, ❌ für Falsch)
    if (result.correct) {
      allOptions[index].classList.add("correct");
      allOptions[index].insertAdjacentHTML(
        "beforeend",
        '<div class="icon tick">⚓</div>'
      );
    } else {
      allOptions[index].classList.add("incorrect");
      allOptions[index].insertAdjacentHTML(
        "beforeend",
        '<div class="icon cross">❌</div>'
      );

      // Richtige Antwort laut Backend markieren
      // result.correctAnswerIndex kommt vom Backend (war früher: questions[i].answer)
      allOptions[result.correctAnswerIndex].classList.add("correct");
      allOptions[result.correctAnswerIndex].insertAdjacentHTML(
        "beforeend",
        '<div class="icon tick">⚓</div>'
      );
    }

    // Alle Optionen sperren (kein Mehrfachklick)
    for (let i = 0; i < allOptions.length; i++) {
      allOptions[i].classList.add("disabled");
    }
    next_btn.classList.add("show");
  } catch (error) {
    alert("Fehler: Antwort konnte nicht gespeichert werden.");
  }
}

// --- LOGIK: FORTSCHRITT AKTUALISIEREN ---
// Ersetzt die alte queCount/correctAnswer Variable.
// Jetzt kommt der Fortschritt von GET /api/categories.
async function updateProgress() {
  try {
    const response = await fetch(`${API_BASE}/categories`);
    const categories = await response.json();
    const currentCat = categories.find((c) => c.id === CATEGORY_ID);

    if (currentCat) {
      // "X von Y korrekt gelöst" im Footer
      bottom_ques_counter.innerHTML = `<span><p>${currentCat.correctlyAnswered}</p> von <p>${currentCat.totalQuestions}</p> korrekt gelöst</span>`;
    }
  } catch (e) {
    console.warn("Fortschritt konnte nicht geladen werden.");
  }
}

// --- UI: ABSCHLUSS-SCREEN ---
// Zeigt result_box wenn alle Fragen der Kategorie korrekt beantwortet wurden.
function showResult(message) {
  quiz_box.classList.remove("activeQuiz");
  result_box.classList.add("activeResult");
  result_box.querySelector(".score_text").innerHTML = `<span>${message}</span>`;
}

// --- NEXT BUTTON TRIGGER ---
next_btn.onclick = () => {
  loadNextQuestion();
};
