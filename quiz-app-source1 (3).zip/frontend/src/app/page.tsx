"use client";

import { useState, useEffect } from "react";
import { Category } from "@/types/quiz";
import { fetchCategories } from "@/lib/api";
import CategoryCard from "@/components/CategoryCard";
import QuizView from "@/components/QuizView";

export default function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);

  const loadCategories = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchCategories();
      setCategories(data);
    } catch (err) {
      setError("Fehler beim Laden der Kategorien. Ist das Backend aktiv?");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadCategories(); }, []);

  const handleProgressUpdate = (categoryId: number, newProgress: number) => {
    setCategories(prev => prev.map(cat => {
      if (cat.id === categoryId) {
        // Wir berechnen 'correctlyAnswered' basierend auf dem neuen Prozentwert zurück
        const newCorrect = Math.round((newProgress / 100) * cat.totalQuestions);
        return { ...cat, correctlyAnswered: newCorrect };
      }
      return cat;
    }));
  };

  if (selectedCategory) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50/30 py-8 px-4">
        <QuizView
          categoryId={selectedCategory.id}
          categoryName={selectedCategory.name}
          onBack={() => { setSelectedCategory(null); loadCategories(); }}
          onProgressUpdate={handleProgressUpdate}
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h1 className="text-4xl font-black text-blue-900 mb-8">BootsschuleX</h1>
      {loading ? (
        <p>Hissen der Segel...</p>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {categories.map((cat) => (
            <CategoryCard 
              key={cat.id} 
              category={cat} 
              onClick={(id) => setSelectedCategory(categories.find(c => c.id === id)!)} 
            />
          ))}
        </div>
      )}
    </div>
  );
}

