import type { Metadata } from "next";
import "./global.css";

export const metadata: Metadata = {
  title: "BootsschuleX | Maritimes Quiz für Binnen & See",
  description: "Optimiere deine Prüfungsvorbereitung für den Bootsführerschein.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de" className="scroll-smooth">
      <body className="min-h-screen bg-maritime-pattern font-sans antialiased">
        <div className="fixed bottom-4 right-4 opacity-5 text-9xl select-none pointer-events-none">
          ⚓
        </div>
        <main className="relative z-10">
          {children}
        </main>
      </body>
    </html>
  );
}
