export interface Category {
  id: number;
  name: string;
  totalQuestions: number;     // Entspricht 'total' aus dem Backend
  correctlyAnswered: number;  // Entspricht 'correct' aus dem Backend
  // Optionale Felder für UI-Erweiterungen
  description?: string;
  newCount?: number;
  difficulty?: number;
}

export interface NextQuestion {
  questionId: number;
  questionText: string;
  answerOptions: string[];
  allAnswered: boolean;
  message?: string;
}

export interface AnswerResult {
  correct: boolean;
  correctAnswerIndex: number;
  categoryProgress?: number; // Vom Backend für Live-Updates geliefert
}

