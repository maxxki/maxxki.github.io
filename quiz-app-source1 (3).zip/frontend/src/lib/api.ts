import { Category, NextQuestion, AnswerResult } from "@/types/quiz";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || "http://localhost:8080/api";

export async function fetchCategories(): Promise<Category[]> {
  const res = await fetch(`${API_BASE}/categories`);
  if (!res.ok) throw new Error("Kategorien konnten nicht geladen werden");
  return res.json();
}

export async function fetchNextQuestion(categoryId: number): Promise<NextQuestion> {
  const res = await fetch(`${API_BASE}/categories/${categoryId}/next-question`);
  if (!res.ok) throw new Error("Frage konnte nicht geladen werden");
  return res.json();
}

export async function submitAnswer(questionId: number, selectedAnswerIndex: number): Promise<AnswerResult> {
  const res = await fetch(`${API_BASE}/questions/${questionId}/answer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ selectedAnswerIndex }),
  });
  if (!res.ok) throw new Error("Antwort konnte nicht gespeichert werden");
  return res.json();
}
