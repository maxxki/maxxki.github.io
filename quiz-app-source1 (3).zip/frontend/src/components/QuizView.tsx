"use client";

import { useState, useEffect, useCallback } from "react";
import { NextQuestion, AnswerResult } from "@/types/quiz";
import { fetchNextQuestion, submitAnswer } from "@/lib/api";

interface Props {
  categoryId: number;
  categoryName: string;
  onBack: () => void;
  onProgressUpdate?: (categoryId: number, progress: number) => void;  // NEU
}

type OptionState = "default" | "correct" | "incorrect";

export default function QuizView({ categoryId, categoryName, onBack, onProgressUpdate }: Props) {
  const [question, setQuestion] = useState<NextQuestion | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [optionStates, setOptionStates] = useState<OptionState[]>([]);
  const [answered, setAnswered] = useState(false);
  const [result, setResult] = useState<AnswerResult | null>(null);

  const loadQuestion = useCallback(async () => {
    setLoading(true);
    setError(null);
    setAnswered(false);
    setResult(null);
    try {
      const data = await fetchNextQuestion(categoryId);
      setQuestion(data);
      if (!data.allAnswered) {
        setOptionStates(new Array(data.answerOptions.length).fill("default"));
      }
    } catch (e) {
      setError("Fehler beim Laden der Frage. Ist das Backend aktiv?");
    } finally {
      setLoading(false);
    }
  }, [categoryId]);

  useEffect(() => {
    loadQuestion();
  }, [loadQuestion]);

  const handleAnswer = async (index: number) => {
    if (answered || !question || question.allAnswered) return;

    try {
      const res = await submitAnswer(question.questionId, index);
      setResult(res);
      setAnswered(true);

      // NEU: Progress an Parent melden
      if (res.categoryProgress !== undefined && onProgressUpdate) {
        onProgressUpdate(categoryId, res.categoryProgress);
      }

      const newStates: OptionState[] = question.answerOptions.map((_, i) => {
        if (i === index && res.correct) return "correct";
        if (i === index && !res.correct) return "incorrect";
        if (i === res.correctAnswerIndex && !res.correct) return "correct";
        return "default";
      });
      setOptionStates(newStates);
    } catch {
      setError("Antwort konnte nicht gespeichert werden.");
    }
  };

  const stateClasses: Record<OptionState, string> = {
    default: "bg-white border-gray-200 hover:border-blue-400 hover:bg-blue-50 cursor-pointer",
    correct: "bg-green-50 border-green-500 text-green-800",
    incorrect: "bg-red-50 border-red-500 text-red-800",
  };

  if (loading) return <p className="text-center mt-12 text-gray-500">Lade Frage…</p>;
  if (error) return <p className="text-center mt-12 text-red-500">{error}</p>;
  if (!question) return null;

  if (question.allAnswered) {
    return (
      <div className="text-center mt-20">
        <div className="text-6xl mb-4">🎉</div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{question.message}</h2>
        <button
          onClick={onBack}
          className="mt-6 px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
        >
          ← Zurück zur Übersicht
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <button
          onClick={onBack}
          className="text-gray-500 hover:text-gray-800 transition-colors text-sm"
        >
          ← Übersicht
        </button>
        <span className="text-gray-300">|</span>
        <span className="text-blue-600 font-medium">{categoryName}</span>
      </div>

      {/* Frage */}
      <div className="bg-white rounded-2xl shadow-md p-8 mb-6">
        <p className="text-lg font-semibold text-gray-800 leading-relaxed">
          {question.questionText}
        </p>
      </div>

      {/* Optionen */}
      <div className="space-y-3">
        {question.answerOptions.map((option, index) => (
          <button
            key={index}
            onClick={() => handleAnswer(index)}
            disabled={answered}
            className={`w-full text-left px-6 py-4 rounded-xl border-2 transition-all duration-200 font-medium ${stateClasses[optionStates[index] ?? "default"]} ${answered ? "cursor-not-allowed" : ""}`}
          >
            <span className="mr-3 text-gray-400 font-mono">
              {String.fromCharCode(65 + index)}.
            </span>
            {option}
            {optionStates[index] === "correct" && <span className="float-right">✅</span>}
            {optionStates[index] === "incorrect" && <span className="float-right">❌</span>}
          </button>
        ))}
      </div>

      {/* Feedback & Weiter-Button */}
      {answered && result && (
        <div className="mt-6 flex items-center justify-between">
          <p className={`font-semibold text-lg ${result.correct ? "text-green-600" : "text-red-500"}`}>
            {result.correct ? "🎉 Richtig!" : "❌ Leider falsch."}
          </p>
          <button
            onClick={loadQuestion}
            className="px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors font-medium"
          >
            Nächste Frage →
          </button>
        </div>
      )}
    </div>
  );
}
