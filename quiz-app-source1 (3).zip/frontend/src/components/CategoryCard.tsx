"use client";

import { Category } from "@/types/quiz";

interface CategoryCardProps {
  category: Category;
  onClick: (id: number) => void;
}

export default function CategoryCard({ category, onClick }: CategoryCardProps) {
  // Dynamische Berechnung des Fortschritts
  const total = category.totalQuestions || 0;
  const correct = category.correctlyAnswered || 0;
  const progressPercentage = total > 0 ? Math.round((correct / total) * 100) : 0;

  const getIcon = (name: string) => {
    const icons: Record<string, string> = {
      'Seezeichen & Feuer': '⚓',
      'Fahrregeln': '⛵',
      'Knotenkunde': '🪢',
      'Binnen': '🚤',
      'See': '🌊',
    };
    // Falls kein Icon gematcht wird, nehmen wir ein Standard-Icon
    return icons[name] || '🧭';
  };

  return (
    <div 
      onClick={() => onClick(category.id)}
      className="nautical-card group cursor-pointer transform transition-all duration-300 hover:scale-105"
    >
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-t from-blue-100/50 to-transparent"></div>
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <span className="text-5xl filter drop-shadow-lg transform group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
            {getIcon(category.name)}
          </span>
          
          {/* Fortschrittsring */}
          <div className="relative w-12 h-12">
            <svg className="w-12 h-12 transform -rotate-90">
              <circle cx="24" cy="24" r="20" stroke="currentColor" strokeWidth="4" fill="none" className="text-slate-200" />
              <circle
                cx="24" cy="24" r="20" stroke="currentColor" strokeWidth="4" fill="none"
                strokeDasharray={`${2 * Math.PI * 20}`}
                strokeDashoffset={`${2 * Math.PI * 20 * (1 - progressPercentage / 100)}`}
                className="text-blue-600 transition-all duration-1000"
              />
            </svg>
            <span className="absolute inset-0 flex items-center justify-center text-sm font-bold text-blue-700">
              {progressPercentage}%
            </span>
          </div>
        </div>

        <h3 className="text-2xl font-bold text-slate-800 mb-2 group-hover:text-blue-700 transition-colors">
          {category.name}
        </h3>
        
        <div className="flex items-center gap-2 text-slate-600 mb-4">
          <span className="sand-badge">
            {total} Fragen
          </span>
          {progressPercentage === 100 && (
            <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded-full text-xs font-semibold">
              GEMEISTERT
            </span>
          )}
        </div>

        <p className="text-slate-600 text-sm line-clamp-2 mb-4">
          {correct} von {total} Fragen korrekt beantwortet.
        </p>

        <div className="flex items-center justify-between">
          <span className="text-blue-600 font-medium group-hover:translate-x-2 transition-transform duration-300 inline-flex items-center gap-1">
            Quiz starten <span className="text-xl">→</span>
          </span>
        </div>
      </div>
    </div>
  );
}

