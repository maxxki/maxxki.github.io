/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        maritime: {
          navy: {
            50: '#e6f3ff',
            100: '#b0d4ff',
            200: '#8ab9ff',
            300: '#5c9aff',
            400: '#3b82f6',
            500: '#1e4b8f',
            600: '#163a6b',
            700: '#102b4f',
            800: '#0b1f3a',
            900: '#071528',
          },
          sand: {
            50: '#fdf8f0',
            100: '#faf0e0',
            200: '#f5e5d0',
            300: '#f0dbbd',
            400: '#e5c9a4',
            500: '#d4b28c',
          },
          wave: {
            light: '#7dd3fc',
            DEFAULT: '#38bdf8',
            dark: '#0284c7',
          }
        }
      },
      fontFamily: {
        sans: ['system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      animation: {
        'spin-slow': 'spin 3s linear infinite',
        'float': 'float 3s ease-in-out infinite',
        'wave': 'wave 8s linear infinite',
        'fade-in': 'fadeIn 0.5s ease-out forwards',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        wave: {
          '0%': { transform: 'translateX(0) translateY(0)' },
          '50%': { transform: 'translateX(-25%) translateY(5px)' },
          '100%': { transform: 'translateX(-50%) translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      backgroundImage: {
        'water-pattern': "url(\"data:image/svg+xml,%3Csvg width='100' height='20' viewBox='0 0 100 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 10 Q 25 0, 50 10 T 100 10' stroke='%233b82f6' fill='none' stroke-opacity='0.1' stroke-width='2'/%3E%3C/svg%3E\")",
      },
    },
  },
  plugins: [],
}
