#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────
#  Java Analyser – Start Script
#  Works on Termux (Android) and Desktop (Linux/macOS)
#
#  Modes:
#    ./run.sh                  → start API server (port 7070)
#    ./run.sh --cli <path>     → CLI mode, analyse <path>
#    ./run.sh --port 8080      → server on custom port
# ─────────────────────────────────────────────────────────

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PORT=7070
MODE="server"
TARGET="target"

# ── Parse args ────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case $1 in
    --cli)    MODE="cli"; TARGET="${2:-target}"; shift 2 ;;
    --port)   PORT="$2"; shift 2 ;;
    --help)
      echo "Usage: ./run.sh [--cli <path>] [--port <port>]"
      echo "  (no args)         Start API server on port 7070"
      echo "  --cli <path>      Analyse <path> and print report"
      echo "  --port <n>        Use custom port for server"
      exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ── Check dependencies ────────────────────────────────────
check() {
  command -v "$1" > /dev/null 2>&1 || {
    echo "  ERROR: '$1' not found."
    if [ -d "/data/data/com.termux" ]; then
      echo "  Termux: pkg install $2"
    else
      echo "  Linux:  sudo apt install $2"
      echo "  macOS:  brew install $2"
    fi
    exit 1
  }
}

echo ""
echo "=================================================="
echo "  Java Analyser"
echo "=================================================="
check node  "nodejs"
check javac "openjdk-17"
check java  "openjdk-17"
echo "  node  $(node --version)"
echo "  java  $(java -version 2>&1 | head -1 | awk '{print $3}' | tr -d '"')"
echo "=================================================="

# ── Compile ───────────────────────────────────────────────
if [ ! -f Orchestrator.class ] || [ Orchestrator.java -nt Orchestrator.class ]; then
  echo "  Compiling Orchestrator.java ..."
  javac Orchestrator.java
  echo "  Done."
fi

mkdir -p output

# ── Run ───────────────────────────────────────────────────
if [ "$MODE" = "server" ]; then
  echo ""
  echo "  Starting server on port $PORT ..."
  echo "  Open: http://localhost:$PORT"
  echo "  Frontend: open frontend/index.html in your browser"
  echo ""
  echo "  Press Ctrl+C to stop."
  echo "=================================================="
  echo ""
  java Orchestrator --server "$PORT"
else
  echo ""
  echo "  CLI mode → analysing: $TARGET"
  echo "=================================================="
  echo ""
  java Orchestrator "$TARGET"
fi
