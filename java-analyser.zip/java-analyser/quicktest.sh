#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────
#  Java Analyser – Quick Test
#  Tests every component before first use.
# ─────────────────────────────────────────────────────────

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PASS=0; FAIL=0

ok()   { echo "  ✅  $1"; PASS=$((PASS+1)); }
fail() { echo "  ❌  $1"; FAIL=$((FAIL+1)); }

check() {
  local label="$1"; shift
  if "$@" > /dev/null 2>&1; then ok "$label"; else fail "$label"; fi
}

echo ""
echo "=== Java Analyser – Quick Test ==="
echo ""

# ── Create synthetic Java project ────────────────────────
TMP="$SCRIPT_DIR/_test_tmp"
mkdir -p "$TMP/com/example/service"

cat > "$TMP/com/example/Main.java" << 'JAVA'
package com.example;

import java.util.List;
import java.util.ArrayList;
import org.springframework.boot.SpringApplication;

// TODO: add logging
@SpringBootApplication
public class Main {
    private static final String APP_NAME = "Test";
    private int counter = 0;

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    public void increment() { counter++; }
    private String greet(String name) { return "Hi " + name; }
}
JAVA

cat > "$TMP/com/example/service/UserService.java" << 'JAVA'
package com.example.service;

import java.util.List;
import java.util.Optional;

// FIXME: implement caching
@Service
public class UserService {
    @Autowired
    private UserRepository repo;

    public List<User> findAll() { return repo.findAll(); }
    public Optional<User> findById(Long id) { return repo.findById(id); }
    public User save(User u) { return repo.save(u); }
    public void delete(Long id) { repo.deleteById(id); }
}
JAVA

cat > "$TMP/com/example/service/UserServiceTest.java" << 'JAVA'
package com.example.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class UserServiceTest {
    private UserService service;

    @BeforeEach
    void setUp() { service = new UserService(); }

    @Test
    void testFindAll() { assert service.findAll() != null; }

    @Test
    void testSave() { assert service.save(new Object()) != null; }
}
JAVA

echo "Dependency checks:"
check "node available"  node --version
check "java available"  java  -version
check "javac available" javac -version
echo ""

echo "Agent tests:"
FILES=$(echo "$TMP" | node agents/fileReader.js 2>/dev/null)
check "fileReader.js – finds .java files" bash -c "echo '$FILES' | grep -q '.java'"
check "fileReader.js – returns JSON array" bash -c "echo '$FILES' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.length>0?0:1)\""

ANALYSIS=$(echo "$FILES" | node agents/codeAnalyzer.js 2>/dev/null)
check "codeAnalyzer.js – runs without error" bash -c "echo '$ANALYSIS' | node -e \"JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'))\""
check "codeAnalyzer.js – detects classes"    bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.summary.totalClasses>0?0:1)\""
check "codeAnalyzer.js – detects methods"    bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.summary.totalMethods>0?0:1)\""
check "codeAnalyzer.js – detects TODOs"      bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.todos.length>0?0:1)\""
check "codeAnalyzer.js – detects Spring"     bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.frameworks.spring.length>0?0:1)\""
check "codeAnalyzer.js – detects JUnit"      bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.frameworks.junit.length>0?0:1)\""

PAYLOAD=$(node -e "
const p = {
  files: $FILES,
  analysis: JSON.stringify($ANALYSIS),
  project: '$TMP',
  date: new Date().toISOString()
};
process.stdout.write(JSON.stringify(p));
")
REPORT=$(echo "$PAYLOAD" | node agents/mdGenerator.js 2>/dev/null)
check "mdGenerator.js – generates markdown"  bash -c "echo '$REPORT' | grep -q '# Java Project Analysis Report'"
check "mdGenerator.js – includes TODOs"      bash -c "echo '$REPORT' | grep -q 'TODO'"
check "mdGenerator.js – includes packages"   bash -c "echo '$REPORT' | grep -q 'com.example'"
echo ""

echo "Compiler & pipeline:"
check "javac Orchestrator.java" javac Orchestrator.java
check "java Orchestrator (CLI)" java Orchestrator "$TMP"
echo ""

echo "Safety checks:"
WRITE_BLOCKED=$(node -e "
  const fs = require('fs');
  fs.writeFileSync = () => { process.stdout.write('blocked'); process.exit(0); };
  try { fs.writeFileSync('/tmp/test_evil.txt','x'); } catch {}
  process.stdout.write('not-blocked');
" 2>/dev/null)
[ "$WRITE_BLOCKED" = "blocked" ] && ok "write operations are blocked" || fail "write operations NOT blocked"

# Cleanup
rm -rf "$TMP" Orchestrator.class 2>/dev/null || true

echo ""
echo "==================================="
printf "  Passed: %s  |  Failed: %s\n" "$PASS" "$FAIL"
echo "==================================="
if [ "$FAIL" -eq 0 ]; then
  echo "  All good – run ./run.sh to start! 🚀"
else
  echo "  Fix the failures above before use."
fi
echo ""
