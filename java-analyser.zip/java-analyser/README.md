# Java Analyser 🤖

> A lightweight multi-agent system that analyses any Java project and produces a professional Markdown report — with a clean React frontend.

![Java](https://img.shields.io/badge/Java-17+-orange?style=flat-square)
![Node.js](https://img.shields.io/badge/Node.js-18+-green?style=flat-square)
![No Dependencies](https://img.shields.io/badge/dependencies-none-brightgreen?style=flat-square)
![Termux](https://img.shields.io/badge/Termux-compatible-blue?style=flat-square)

---

## How it works

Three specialised agents, orchestrated by a Java HTTP server:

```
┌─────────────────────────────────────────────────┐
│              Orchestrator.java                  │
│         (built-in HTTP server, no Maven)        │
└──────┬──────────────┬──────────────┬────────────┘
       │              │              │
  fileReader.js  codeAnalyzer.js  mdGenerator.js
  (scan files)   (deep analysis)  (render report)
```

Each agent is **read-only** — no file writes, no network calls, no side effects.

---

## What gets analysed

| Section | Details |
|---|---|
| Summary | Files, lines, code/comment ratio, total size |
| Package Structure | All packages with file counts |
| Class Inventory | Classes, interfaces, enums per file |
| Method Details | All methods with parameter counts |
| Most Complex Files | Top 10 by method count |
| Largest Files | Top 10 by line count |
| Annotations | All `@Annotation` usages ranked |
| Frameworks | Spring/Boot, Lombok, JUnit auto-detected |
| Imports | Top 30 most used packages |
| TODOs & FIXMEs | All comments with location |

---

## Setup

### Termux (Android)
```bash
pkg update && pkg install openjdk-17 nodejs
```

### Desktop (Linux)
```bash
sudo apt install openjdk-17 nodejs   # Debian/Ubuntu
brew install openjdk node            # macOS
```

---

## Usage

```bash
git clone https://github.com/yourname/java-analyser
cd java-analyser
chmod +x run.sh quicktest.sh

# Validate everything first
./quicktest.sh

# Start the API server
./run.sh

# Then open frontend/index.html in your browser
# Enter the path to your Java project and hit Analyse
```

### CLI mode (no browser needed)
```bash
./run.sh --cli path/to/your/java/project
```

### Custom port
```bash
./run.sh --port 8080
```

---

## File structure

```
java-analyser/
├── Orchestrator.java         ← HTTP server + agent runner (pure JDK)
├── agents/
│   ├── fileReader.js         ← recursive .java file scanner
│   ├── codeAnalyzer.js       ← extracts classes, methods, fields, …
│   └── mdGenerator.js        ← renders the Markdown report
├── frontend/
│   └── index.html            ← React + Tailwind UI (single file, CDN)
├── output/                   ← generated reports land here
├── run.sh                    ← one-click start
└── quicktest.sh              ← validates all components
```

---

## Security

- **Read-only agents** — `writeFile`, `unlink`, `mkdir` are blocked at the Node.js level
- **Path guard** — the server rejects any target path outside the project root
- **No external dependencies** — pure JDK + Node.js standard library only
- **Stdin/stdout only** — agents communicate only via pipes, no temp files

---

## Requirements

- Java 17+
- Node.js 18+
- A browser (for the frontend)

No Maven. No npm install. No config files.
