import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Java Project Analyser – Orchestrator with built-in HTTP server.
 * No Maven, no external dependencies. Pure JDK.
 *
 * CLI mode:  java Orchestrator <path>
 * API mode:  java Orchestrator --server [port]   (default: 7070)
 */
public class Orchestrator {

    static final String AGENTS_DIR =
            Paths.get("").toAbsolutePath() + "/agents";
    static final String OUTPUT_DIR = "output";
    static final int    TIMEOUT_SEC = 120;
    static final int    DEFAULT_PORT = 7070;

    public static void main(String[] args) throws Exception {

        // ── Server mode ───────────────────────────────────────────────────
        if (args.length > 0 && args[0].equals("--server")) {
            int port = (args.length > 1) ? Integer.parseInt(args[1]) : DEFAULT_PORT;
            startServer(port);
            return;
        }

        // ── CLI mode ──────────────────────────────────────────────────────
        String target = (args.length > 0) ? args[0] : "target";
        System.out.println("\n" + "=".repeat(52));
        System.out.println("  Java Project Analyser – CLI");
        System.out.println("=".repeat(52));
        String result = runPipeline(target);
        System.out.println(result);
    }

    // ── HTTP Server ───────────────────────────────────────────────────────────

    static void startServer(int port) throws Exception {
        Files.createDirectories(Paths.get(OUTPUT_DIR));

        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newFixedThreadPool(4));

        // CORS + routing
        server.createContext("/api/analyse", ex -> {
            addCors(ex);
            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"GET".equals(ex.getRequestMethod()))    { respond(ex, 405, ""); return; }

            String query  = ex.getRequestURI().getQuery();
            String target = parseParam(query, "path");
            if (target == null || target.isEmpty()) target = "target";

            // Safety: stay inside cwd
            Path base = Paths.get(".").toAbsolutePath().normalize();
            Path tgt  = Paths.get(target).toAbsolutePath().normalize();
            if (!tgt.startsWith(base)) {
                respond(ex, 403, json("error", "Path outside project root."));
                return;
            }
            if (!Files.isDirectory(tgt)) {
                respond(ex, 404, json("error", "Directory not found: " + target));
                return;
            }

            try {
                String filesJson   = runAgent("fileReader.js",   target);
                String analysisJson= runAgent("codeAnalyzer.js", filesJson);
                String payload     = buildPayload(filesJson, analysisJson, target);
                String report      = runAgent("mdGenerator.js",  payload);

                // Save report
                String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
                String name = OUTPUT_DIR + "/report_" + ts + ".md";
                Files.writeString(Paths.get(name), report);

                // Return JSON with both raw analysis and markdown
                String body = "{\"status\":\"ok\","
                    + "\"report\":" + jsonString(report) + ","
                    + "\"analysis\":" + analysisJson + ","
                    + "\"savedAs\":" + jsonString(name) + "}";
                respond(ex, 200, body);

            } catch (Exception e) {
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        // Health check
        server.createContext("/api/health", ex -> {
            addCors(ex);
            boolean agentsOk = Files.isDirectory(Paths.get(AGENTS_DIR));
            respond(ex, 200, "{\"status\":\"ok\",\"agents\":" + agentsOk + "}");
        });


        // Serve frontend at http://localhost:<port>/
        server.createContext("/", ex -> {
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }
            Path html = Paths.get("frontend/index.html");
            if (!Files.exists(html)) {
                byte[] msg = "frontend/index.html not found".getBytes();
                ex.getResponseHeaders().add("Content-Type", "text/plain");
                ex.sendResponseHeaders(404, msg.length);
                try (OutputStream o = ex.getResponseBody()) { o.write(msg); }
                return;
            }
            byte[] bytes = Files.readAllBytes(html);
            ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(200, bytes.length);
            try (OutputStream o = ex.getResponseBody()) { o.write(bytes); }
        });

        server.start();
        System.out.println("\n" + "=".repeat(52));
        System.out.println("  Java Project Analyser – API Server");
        System.out.println("=".repeat(52));
        System.out.println("  http://localhost:" + port);
        System.out.println("  Agents: " + AGENTS_DIR);
        System.out.println("=".repeat(52));
        System.out.println("  Press Ctrl+C to stop.\n");
    }

    // ── Pipeline ──────────────────────────────────────────────────────────────

    static String runPipeline(String target) throws Exception {
        Files.createDirectories(Paths.get(OUTPUT_DIR));
        System.out.println("[1/3] Scanning Java files …");
        String filesJson    = runAgent("fileReader.js",   target);
        System.out.println("[2/3] Analysing code …");
        String analysisJson = runAgent("codeAnalyzer.js", filesJson);
        System.out.println("[3/3] Generating report …");
        String payload      = buildPayload(filesJson, analysisJson, target);
        String report       = runAgent("mdGenerator.js",  payload);
        String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
        String name = OUTPUT_DIR + "/report_" + ts + ".md";
        Files.writeString(Paths.get(name), report);
        System.out.println("\nSaved → " + name + "\n");
        return report;
    }

    // ── Agent runner ──────────────────────────────────────────────────────────

    static String runAgent(String agentName, String input) throws Exception {
        String agentPath = AGENTS_DIR + "/" + agentName;
        if (!Files.exists(Paths.get(agentPath)))
            throw new Exception("Agent not found: " + agentPath);

        // --max-old-space-size: enough heap for large projects
        ProcessBuilder pb = new ProcessBuilder("node", "--max-old-space-size=512", agentPath);
        pb.redirectErrorStream(false);
        Process p = pb.start();

        // Write stdin then close – signals EOF to the agent
        try (OutputStream stdin = p.getOutputStream()) {
            stdin.write(input.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }

        // Read stdout + stderr concurrently to avoid pipe-buffer deadlock on large output
        final StringBuilder outBuf = new StringBuilder();
        final StringBuilder errBuf = new StringBuilder();
        Thread outReader = new Thread(() -> {
            try { outBuf.append(new String(p.getInputStream().readAllBytes())); }
            catch (IOException ignored) {}
        });
        Thread errReader = new Thread(() -> {
            try { errBuf.append(new String(p.getErrorStream().readAllBytes())); }
            catch (IOException ignored) {}
        });
        outReader.start();
        errReader.start();

        if (!p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new Exception("Timeout (" + TIMEOUT_SEC + "s): " + agentName);
        }
        outReader.join();
        errReader.join();

        String out = outBuf.toString().trim();
        String err = errBuf.toString().trim();
        if (p.exitValue() != 0)
            throw new Exception("Agent '" + agentName + "' failed: " + (err.isEmpty() ? out : err));
        return out;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    static String buildPayload(String filesJson, String analysisJson, String project) {
        return "{\"files\":"    + filesJson
             + ",\"analysis\":" + analysisJson
             + ",\"project\":"  + jsonString(project)
             + ",\"date\":"     + jsonString(LocalDateTime.now().toString())
             + "}";
    }

    static String jsonString(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\","\\\\").replace("\"","\\\"")
                       .replace("\n","\\n").replace("\r","\\r")
                       .replace("\t","\\t") + "\"";
    }

    static String json(String key, String value) {
        return "{\"" + key + "\":" + jsonString(value) + "}";
    }

    static String parseParam(String query, String key) {
        if (query == null) return null;
        for (String part : query.split("&")) {
            String[] kv = part.split("=", 2);
            if (kv.length == 2 && kv[0].equals(key))
                return java.net.URLDecoder.decode(kv[1], java.nio.charset.StandardCharsets.UTF_8);
        }
        return null;
    }

    static void addCors(HttpExchange ex) {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin",  "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
    }

    static void respond(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }
}
