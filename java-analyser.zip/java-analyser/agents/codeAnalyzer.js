#!/usr/bin/env node
/**
 * codeAnalyzer.js
 * Receives JSON array of file objects on stdin.
 * Returns deep analysis JSON for Java files.
 * READ-ONLY.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ── Read-only protection ─────────────────────────────────────────────────────
fs.writeFileSync = fs.writeFile = fs.appendFileSync = fs.appendFile =
fs.unlinkSync    = fs.unlink    = fs.rmdirSync      = fs.rmdir      =
fs.mkdirSync     = fs.mkdir     = () => { process.exit(99); };

// ── Regex patterns for Java constructs ───────────────────────────────────────
const RX = {
    packageDecl:   /^\s*package\s+([\w.]+)\s*;/m,
    imports:       /^\s*import\s+(static\s+)?([\w.*]+)\s*;/gm,
    classDecl:     /(?:^|\n)\s*(?:(?:public|private|protected|abstract|final|static)\s+)*(?:class|interface|enum|record)\s+(\w+)(?:\s*<[^>]*>)?(?:\s+extends\s+[\w.<>, ]+)?(?:\s+implements\s+[\w.<>, ]+)?\s*\{/g,
    methodDecl:    /(?:^|\n)\s*(?:(?:@\w+(?:\([^)]*\))?\s+)*)?(?:public|private|protected)\s+(?:static\s+|final\s+|synchronized\s+|abstract\s+)*(?:[\w<>\[\].,? ]+\s+)(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,. ]+)?\s*[\{;]/g,
    fieldDecl:     /(?:^|\n)\s*(?:(?:public|private|protected|static|final|volatile|transient)\s+)+(?:[\w<>\[\].,? ]+)\s+(\w+)\s*(?:=|;)/g,
    annotations:   /@(\w+)(?:\([^)]*\))?/g,
    singleComment: /\/\/[^\n]*/g,
    blockComment:  /\/\*[\s\S]*?\*\//g,
    todoFixme:     /\/\/\s*(TODO|FIXME|HACK|XXX)[^\n]*/gi,
    methodCall:    /(\w+)\s*\.\s*(\w+)\s*\(/g,
    springAnno:    /@(Controller|RestController|Service|Repository|Component|Bean|Autowired|RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping|Entity|Table|SpringBootApplication)/g,
    lombokAnno:    /@(Data|Getter|Setter|Builder|NoArgsConstructor|AllArgsConstructor|RequiredArgsConstructor|Slf4j|ToString|EqualsAndHashCode)/g,
    junitAnno:     /@(Test|BeforeEach|AfterEach|BeforeAll|AfterAll|ParameterizedTest|MockBean|Mock|InjectMocks|ExtendWith)/g,
};

// ── Main ──────────────────────────────────────────────────────────────────────
let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', c => { inputBuf += c; });
process.stdin.on('end', () => {
    let files;
    try { files = JSON.parse(inputBuf.trim()); }
    catch (e) {
        process.stderr.write('Invalid JSON input: ' + e.message + '\n');
        process.exit(1);
    }

    const result = {
        summary: {
            totalFiles:   0,
            totalLines:   0,
            totalClasses: 0,
            totalMethods: 0,
            totalFields:  0,
            totalImports: 0,
            codeLines:    0,
            commentLines: 0,
            blankLines:   0,
            totalSizeKB:  0,
        },
        packages:    {},   // pkg -> [filename]
        imports:     {},   // pkg -> count
        annotations: {},   // annotation -> count
        frameworks:  { spring: [], lombok: [], junit: [] },
        todos:       [],
        files:       [],
        topMethods:  [],   // files with most methods
        largestFiles:[],   // by line count
    };

    for (const f of files) {
        let content;
        try { content = fs.readFileSync(f.path, 'utf8'); }
        catch { continue; }

        const fileInfo = analyseFile(f, content, result);
        result.files.push(fileInfo);
        result.summary.totalFiles++;
    }

    // Sort helpers
    result.topMethods   = [...result.files].sort((a,b)=>b.methods.length - a.methods.length).slice(0,10);
    result.largestFiles = [...result.files].sort((a,b)=>b.lines - a.lines).slice(0,10);
    result.summary.totalSizeKB = +(files.reduce((s,f)=>s+f.size, 0) / 1024).toFixed(2);

    process.stdout.write(JSON.stringify(result, null, 0) + '\n');
});

// ── Per-file analysis ─────────────────────────────────────────────────────────
function analyseFile(f, raw, result) {
    // Strip block comments for cleaner counting (keep original for line split)
    const stripped = raw.replace(RX.blockComment, m => '\n'.repeat((m.match(/\n/g)||[]).length));

    const lines       = raw.split('\n');
    const codeL       = lines.filter(l => l.trim() && !l.trim().startsWith('//')).length;
    const commentL    = lines.filter(l => l.trim().startsWith('//')).length;
    const blankL      = lines.filter(l => !l.trim()).length;

    result.summary.totalLines   += lines.length;
    result.summary.codeLines    += codeL;
    result.summary.commentLines += commentL;
    result.summary.blankLines   += blankL;

    // Package
    const pkgMatch = raw.match(RX.packageDecl);
    const pkg      = pkgMatch ? pkgMatch[1] : '(default)';
    if (!result.packages[pkg]) result.packages[pkg] = [];
    result.packages[pkg].push(f.relative);

    // Imports
    const importMatches = [...raw.matchAll(RX.imports)];
    result.summary.totalImports += importMatches.length;
    for (const m of importMatches) {
        const imp = m[2].replace(/\.\w+$/, ''); // group to package level
        result.imports[imp] = (result.imports[imp] || 0) + 1;
    }

    // Classes / Interfaces / Enums
    const classMatches = [...stripped.matchAll(RX.classDecl)];
    result.summary.totalClasses += classMatches.length;
    const classes = classMatches.map(m => m[1]);

    // Methods
    const methodMatches = [...stripped.matchAll(RX.methodDecl)];
    result.summary.totalMethods += methodMatches.length;
    const methods = methodMatches.map(m => ({
        name:   m[1],
        params: m[2].trim() ? m[2].trim().split(',').length : 0,
    }));

    // Fields
    const fieldMatches = [...stripped.matchAll(RX.fieldDecl)];
    result.summary.totalFields += fieldMatches.length;

    // Annotations
    for (const m of raw.matchAll(RX.annotations)) {
        result.annotations[m[1]] = (result.annotations[m[1]] || 0) + 1;
    }

    // Framework detection
    for (const m of raw.matchAll(RX.springAnno))
        if (!result.frameworks.spring.includes(f.relative)) result.frameworks.spring.push(f.relative);
    for (const m of raw.matchAll(RX.lombokAnno))
        if (!result.frameworks.lombok.includes(f.relative)) result.frameworks.lombok.push(f.relative);
    for (const m of raw.matchAll(RX.junitAnno))
        if (!result.frameworks.junit.includes(f.relative)) result.frameworks.junit.push(f.relative);

    // TODOs / FIXMEs
    for (const m of raw.matchAll(RX.todoFixme))
        result.todos.push({ file: f.relative, note: m[0].trim() });

    return {
        name:       f.name,
        relative:   f.relative,
        package:    pkg,
        sizeKB:     +(f.size / 1024).toFixed(2),
        lines:      lines.length,
        codeLines:  codeL,
        classes,
        methods,
        fields:     fieldMatches.length,
        imports:    importMatches.length,
    };
}
