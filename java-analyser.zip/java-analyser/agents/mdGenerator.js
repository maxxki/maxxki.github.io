#!/usr/bin/env node
/**
 * mdGenerator.js
 * Receives a JSON payload on stdin: { files, analysis, project, date }
 * Returns a professional Markdown report.
 * READ-ONLY.
 */

'use strict';

const fs = require('fs');
fs.writeFileSync = fs.writeFile = () => { process.exit(99); };

let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', c => { inputBuf += c; });
process.stdin.on('end', () => {
    let payload, analysis;
    try {
        payload  = JSON.parse(inputBuf.trim());
        analysis = typeof payload.analysis === 'string'
            ? JSON.parse(payload.analysis)
            : payload.analysis;
    } catch (e) {
        process.stderr.write('Invalid input: ' + e.message + '\n');
        process.exit(1);
    }

    const s       = analysis.summary || {};
    const date    = new Date(payload.date).toLocaleString('de-DE');
    const project = payload.project || '(unknown)';

    let md = '';

    // ── Title ─────────────────────────────────────────────────────────────────
    md += `# Java Project Analysis Report\n\n`;
    md += `| | |\n|---|---|\n`;
    md += `| **Project** | \`${project}\` |\n`;
    md += `| **Analysed** | ${date} |\n`;
    md += `| **Generator** | Java Analyser v1.0 |\n\n`;
    md += `---\n\n`;

    // ── 1. Summary ────────────────────────────────────────────────────────────
    md += `## 1. Summary\n\n`;
    md += `| Metric | Value |\n|---|---:|\n`;
    md += `| Java files | ${s.totalFiles || 0} |\n`;
    md += `| Total size | ${s.totalSizeKB || 0} KB |\n`;
    md += `| Total lines | ${s.totalLines || 0} |\n`;
    md += `| Code lines | ${s.codeLines || 0} |\n`;
    md += `| Comment lines | ${s.commentLines || 0} |\n`;
    md += `| Blank lines | ${s.blankLines || 0} |\n`;
    md += `| Classes / Interfaces / Enums | ${s.totalClasses || 0} |\n`;
    md += `| Methods | ${s.totalMethods || 0} |\n`;
    md += `| Fields | ${s.totalFields || 0} |\n`;
    md += `| Import statements | ${s.totalImports || 0} |\n\n`;

    const commentRatio = s.totalLines
        ? ((s.commentLines / s.totalLines) * 100).toFixed(1)
        : 0;
    md += `> **Comment ratio:** ${commentRatio}%\n\n`;
    md += `---\n\n`;

    // ── 2. Package Structure ──────────────────────────────────────────────────
    md += `## 2. Package Structure\n\n`;
    const pkgs = analysis.packages || {};
    if (Object.keys(pkgs).length) {
        md += `| Package | Files |\n|---|---:|\n`;
        for (const [pkg, files] of Object.entries(pkgs).sort())
            md += `| \`${pkg}\` | ${files.length} |\n`;
        md += '\n';

        // Tree-like listing per package
        for (const [pkg, files] of Object.entries(pkgs).sort()) {
            md += `<details>\n<summary><code>${pkg}</code> – ${files.length} file(s)</summary>\n\n`;
            for (const f of files.sort())
                md += `- \`${f}\`\n`;
            md += `\n</details>\n\n`;
        }
    } else {
        md += '_No packages detected._\n\n';
    }
    md += `---\n\n`;

    // ── 3. Class Inventory ────────────────────────────────────────────────────
    md += `## 3. Class / Interface / Enum Inventory\n\n`;
    const fileList = analysis.files || [];
    if (fileList.length) {
        md += `| File | Package | Classes | Methods | Fields | Lines |\n`;
        md += `|---|---|---:|---:|---:|---:|\n`;
        for (const f of fileList.sort((a,b)=>a.relative.localeCompare(b.relative))) {
            const classNames = f.classes.length ? f.classes.join(', ') : '—';
            md += `| \`${f.relative}\` | \`${f.package}\` | ${classNames} | ${f.methods.length} | ${f.fields} | ${f.lines} |\n`;
        }
        md += '\n';
    }
    md += `---\n\n`;

    // ── 4. Method Details ─────────────────────────────────────────────────────
    md += `## 4. Method Details\n\n`;
    for (const f of fileList.sort((a,b)=>a.relative.localeCompare(b.relative))) {
        if (!f.methods.length) continue;
        md += `### \`${f.relative}\`\n\n`;
        md += `| Method | Parameters |\n|---|---:|\n`;
        for (const m of f.methods)
            md += `| \`${m.name}()\` | ${m.params} |\n`;
        md += '\n';
    }
    md += `---\n\n`;

    // ── 5. Top 10 – Most Methods ──────────────────────────────────────────────
    md += `## 5. Most Complex Files (by method count)\n\n`;
    const top = (analysis.topMethods || []).filter(f => f.methods.length > 0);
    if (top.length) {
        md += `| Rank | File | Methods | Lines |\n|---:|---|---:|---:|\n`;
        top.forEach((f, i) =>
            md += `| ${i+1} | \`${f.relative}\` | ${f.methods.length} | ${f.lines} |\n`);
        md += '\n';
    } else {
        md += '_No methods found._\n\n';
    }
    md += `---\n\n`;

    // ── 6. Largest Files ──────────────────────────────────────────────────────
    md += `## 6. Largest Files (by line count)\n\n`;
    const large = analysis.largestFiles || [];
    if (large.length) {
        md += `| Rank | File | Lines | Size (KB) |\n|---:|---|---:|---:|\n`;
        large.forEach((f, i) =>
            md += `| ${i+1} | \`${f.relative}\` | ${f.lines} | ${f.sizeKB} |\n`);
        md += '\n';
    }
    md += `---\n\n`;

    // ── 7. Annotations & Frameworks ──────────────────────────────────────────
    md += `## 7. Annotations\n\n`;
    const annos = analysis.annotations || {};
    const annoEntries = Object.entries(annos).sort((a,b)=>b[1]-a[1]);
    if (annoEntries.length) {
        md += `| Annotation | Count |\n|---|---:|\n`;
        for (const [k,v] of annoEntries)
            md += `| \`@${k}\` | ${v} |\n`;
        md += '\n';
    } else {
        md += '_No annotations detected._\n\n';
    }

    const fw = analysis.frameworks || {};
    if ((fw.spring||[]).length || (fw.lombok||[]).length || (fw.junit||[]).length) {
        md += `### Detected Frameworks\n\n`;
        if (fw.spring?.length) md += `- **Spring / Spring Boot** – ${fw.spring.length} file(s)\n`;
        if (fw.lombok?.length) md += `- **Lombok** – ${fw.lombok.length} file(s)\n`;
        if (fw.junit?.length)  md += `- **JUnit** – ${fw.junit.length} file(s)\n`;
        md += '\n';
    }
    md += `---\n\n`;

    // ── 8. Top Imports ────────────────────────────────────────────────────────
    md += `## 8. Most Used Imports\n\n`;
    const imports = Object.entries(analysis.imports || {})
        .sort((a,b)=>b[1]-a[1]).slice(0,20);
    if (imports.length) {
        md += `| Package | Uses |\n|---|---:|\n`;
        for (const [k,v] of imports)
            md += `| \`${k}\` | ${v} |\n`;
        md += '\n';
    } else {
        md += '_No imports found._\n\n';
    }
    md += `---\n\n`;

    // ── 9. TODOs / FIXMEs ────────────────────────────────────────────────────
    md += `## 9. TODOs & FIXMEs\n\n`;
    const todos = analysis.todos || [];
    if (todos.length) {
        md += `| File | Note |\n|---|---|\n`;
        for (const t of todos)
            md += `| \`${t.file}\` | ${t.note.replace(/\|/g, '\\|')} |\n`;
        md += '\n';
    } else {
        md += '_No TODOs or FIXMEs found._ ✅\n\n';
    }
    md += `---\n\n`;

    // ── Footer ────────────────────────────────────────────────────────────────
    md += `*Report generated by Java Analyser v1.0 – read-only static analysis.*\n`;

    process.stdout.write(md + '\n');
});
