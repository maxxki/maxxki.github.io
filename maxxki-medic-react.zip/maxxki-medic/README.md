# MAXXKI MEDIC — React + Spring Boot

Vollständiges medizinisches Dashboard als React-Frontend mit Java Spring Boot REST-Backend.

---

## Projektstruktur

```
maxxki-medic/
├── backend/          ← Spring Boot (Java 17, Maven)
│   └── src/main/java/com/maxxki/medic/
│       ├── MaxxkiMedicApplication.java
│       ├── controller/MedicController.java
│       ├── service/MedicService.java
│       └── model/DashboardData.java
└── frontend/         ← React 18 + Tailwind CSS
    └── src/
        ├── App.jsx
        ├── api/client.js
        └── hooks/useDashboard.js
```

---

## Schnellstart

### 1. Backend starten

```bash
cd backend
./mvnw spring-boot:run
# → läuft auf http://localhost:8080
```

**Voraussetzung:** Java 17+ und Maven (oder nutze den mitgelieferten `mvnw` Wrapper)

### 2. Frontend starten

```bash
cd frontend
npm install
npm start
# → läuft auf http://localhost:3000
```

Der `"proxy": "http://localhost:8080"` in `package.json` leitet alle `/api/*` Requests automatisch weiter — kein CORS-Problem in der Entwicklung.

---

## REST API Endpunkte

| Method | Pfad               | Beschreibung                        |
|--------|--------------------|-------------------------------------|
| GET    | `/api/dashboard`   | Komplettes Dashboard in einem Call  |
| GET    | `/api/patients`    | Alle Patienten                      |
| GET    | `/api/patients?filter=critical` | Nur kritische Patienten |
| GET    | `/api/patients?filter=stable`   | Stabile Patienten       |
| GET    | `/api/departments` | Abteilungsbelegung                  |
| GET    | `/api/emergencies` | Aktive Notfälle                     |
| GET    | `/api/or-schedule` | OP-Tagesplan                        |
| GET    | `/api/equipment`   | Gerätestatus                        |
| GET    | `/api/health`      | Health-Check                        |

---

## Produktion / GitHub Pages

Für GitHub Pages (nur Static-Frontend):

```bash
cd frontend
npm run build
# build/ Ordner deployen
```

Im Build-Modus muss `REACT_APP_API_URL` auf dein Backend zeigen:

```js
// api/client.js
const BASE = process.env.REACT_APP_API_URL || '/api';
```

---

## Nächste Schritte (optional)

- [ ] Echte Datenbank einbinden (PostgreSQL via Spring Data JPA)
- [ ] WebSocket für echten Live-Push statt Polling
- [ ] Spring Security / JWT für Authentifizierung
- [ ] Docker Compose für einfaches Deployment
- [ ] Unit-Tests (JUnit 5 + Mockito backend, Jest frontend)
