package com.maxxki.medic.controller;

import com.maxxki.medic.model.DashboardData;
import com.maxxki.medic.model.Patient;
import com.maxxki.medic.service.MedicService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
// NOTE: In Produktion origins auf deine konkrete Domain beschränken, z.B. "https://deine-domain.de"
@CrossOrigin(origins = "${cors.allowed-origins:http://localhost:3000}")
public class MedicController {

    private final MedicService service;

    public MedicController(MedicService service) {
        this.service = service;
    }

    /** Komplettes Dashboard auf einen Schlag */
    @GetMapping("/dashboard")
    public ResponseEntity<DashboardData> dashboard() {
        return ResponseEntity.ok(service.getDashboardWithLiveVitals());
    }

    /** Nur Patienten – mit zufälligen Live-Vitaldaten, optional gefiltert */
    @GetMapping("/patients")
    public ResponseEntity<List<Patient>> patients(
            @RequestParam(defaultValue = "all") String filter) {

        List<Patient> patients = service.getDashboardWithLiveVitals().getPatients();

        List<Patient> result = switch (filter) {
            case "critical" -> patients.stream().filter(p -> "high".equals(p.getPriority())).toList();
            case "stable"   -> patients.stream().filter(p -> !"high".equals(p.getPriority())).toList();
            default         -> patients;
        };

        return ResponseEntity.ok(result);
    }

    /** Abteilungsstatus */
    @GetMapping("/departments")
    public ResponseEntity<?> departments() {
        return ResponseEntity.ok(service.getDashboard().getDepartments());
    }

    /** Notfälle */
    @GetMapping("/emergencies")
    public ResponseEntity<?> emergencies() {
        return ResponseEntity.ok(service.getDashboard().getEmergencies());
    }

    /** OP-Plan */
    @GetMapping("/or-schedule")
    public ResponseEntity<?> orSchedule() {
        return ResponseEntity.ok(service.getDashboard().getOrSchedule());
    }

    /** Equipment */
    @GetMapping("/equipment")
    public ResponseEntity<?> equipment() {
        return ResponseEntity.ok(service.getDashboard().getEquipment());
    }

    /** Health-Check */
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
            "status",  "UP",
            "service", "MAXXKI-MEDIC"
        ));
    }
}
