package com.maxxki.medic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaxxkiMedicApplication {
    public static void main(String[] args) {
        SpringApplication.run(MaxxkiMedicApplication.class, args);
    }
}
