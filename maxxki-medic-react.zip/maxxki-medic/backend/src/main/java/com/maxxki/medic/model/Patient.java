package com.maxxki.medic.model;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Patient {
    private String id;
    private String name;
    private int age;
    private String condition;
    private String priority; // high | medium | low
    private int hr;
    private String bp;
    private String temp;
}
