package com.maxxki.medic.model;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DashboardData {
    private List<Emergency>  emergencies;
    private List<Patient>    patients;
    private List<Department> departments;
    private List<OrEntry>    orSchedule;
    private List<Equipment>  equipment;
    private int    criticalCount;
    private int    stableCount;
    private int    dischargeReady;
    private int    totalPatients;
    private String systemStatus;
    private String uptime;
    private String location;
}
