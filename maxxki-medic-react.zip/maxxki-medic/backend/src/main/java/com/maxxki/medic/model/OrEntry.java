package com.maxxki.medic.model;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrEntry {
    private String time;
    private String procedure;
    private String surgeon;
    private String status; // active | prep | scheduled | standby
}
