package com.maxxki.medic.service;

import com.maxxki.medic.model.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Random;

@Service
public class MedicService {

    private final Random rng = new Random();

    public DashboardData getDashboard() {
        return DashboardData.builder()
            .systemStatus("ONLINE")
            .uptime("99.8%")
            .location("Klinikum Regensburg")
            .criticalCount(8)
            .stableCount(24)
            .dischargeReady(12)
            .totalPatients(44)
            .emergencies(List.of(
                Emergency.builder().time("14:23:45").location("Station 3B - Zimmer 312").type("Herzstillstand").priority("CRITICAL").build(),
                Emergency.builder().time("14:18:12").location("OP-Saal 2").type("Komplikation").priority("HIGH").build()
            ))
            .patients(buildPatients())
            .departments(List.of(
                Department.builder().name("Notaufnahme").current(18).max(25).build(),
                Department.builder().name("Intensivstation").current(12).max(15).build(),
                Department.builder().name("Chirurgie").current(22).max(30).build(),
                Department.builder().name("Kardiologie").current(8).max(20).build(),
                Department.builder().name("Pädiatrie").current(15).max(18).build()
            ))
            .orSchedule(List.of(
                OrEntry.builder().time("08:00").procedure("Herz-Bypass OP").surgeon("Dr. Müller").status("active").build(),
                OrEntry.builder().time("10:30").procedure("Knie-Arthroskopie").surgeon("Dr. Schmidt").status("prep").build(),
                OrEntry.builder().time("13:00").procedure("Gallenblasen-OP").surgeon("Dr. Weber").status("scheduled").build(),
                OrEntry.builder().time("15:30").procedure("Hüft-Endoprothese").surgeon("Dr. Fischer").status("scheduled").build(),
                OrEntry.builder().time("17:00").procedure("Notfall-OP Reserve").surgeon("Bereitschaft").status("standby").build()
            ))
            .equipment(List.of(
                Equipment.builder().name("MRT-1").icon("MRT").status("online").build(),
                Equipment.builder().name("CT-2").icon("CT").status("online").build(),
                Equipment.builder().name("Röntgen-3").icon("XRY").status("maintenance").build(),
                Equipment.builder().name("Ultraschall").icon("USG").status("online").build(),
                Equipment.builder().name("EKG-Monitor").icon("EKG").status("online").build(),
                Equipment.builder().name("Beatmung-5").icon("BEA").status("online").build()
            ))
            .build();
    }

    /** Liefert Dashboard mit live-zufälligen Herzfrequenzwerten */
    public DashboardData getDashboardWithLiveVitals() {
        DashboardData base = getDashboard();
        return DashboardData.builder()
            .systemStatus(base.getSystemStatus())
            .uptime(base.getUptime())
            .location(base.getLocation())
            .criticalCount(base.getCriticalCount())
            .stableCount(base.getStableCount())
            .dischargeReady(base.getDischargeReady())
            .totalPatients(base.getTotalPatients())
            .emergencies(base.getEmergencies())
            .patients(buildPatients())
            .departments(base.getDepartments())
            .orSchedule(base.getOrSchedule())
            .equipment(base.getEquipment())
            .build();
    }

    private List<Patient> buildPatients() {
        return List.of(
            Patient.builder().id("P-2401-089").name("Meyer, Hans").age(67)
                .condition("Post-OP Ueberwachung").priority("high").hr(randomHr()).bp("125/80").temp("37.2C").build(),
            Patient.builder().id("P-2401-092").name("Schmidt, Anna").age(45)
                .condition("Fraktur Behandlung").priority("medium").hr(randomHr()).bp("118/75").temp("36.8C").build(),
            Patient.builder().id("P-2401-095").name("Weber, Klaus").age(34)
                .condition("Routine Check").priority("low").hr(randomHr()).bp("120/78").temp("36.5C").build(),
            Patient.builder().id("P-2401-098").name("Fischer, Maria").age(56)
                .condition("Intensivueberwachung").priority("high").hr(randomHr()).bp("135/88").temp("38.1C").build(),
            Patient.builder().id("P-2401-101").name("Becker, Thomas").age(28)
                .condition("Voruntersuchung").priority("low").hr(randomHr()).bp("115/72").temp("36.7C").build(),
            Patient.builder().id("P-2401-103").name("Wagner, Lisa").age(72)
                .condition("Kardio Monitoring").priority("medium").hr(randomHr()).bp("142/90").temp("37.4C").build()
        );
    }

    private int randomHr() {
        return rng.nextInt(36) + 60; // 60-95 bpm
    }
}
