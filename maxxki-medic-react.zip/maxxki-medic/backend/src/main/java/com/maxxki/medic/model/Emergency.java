package com.maxxki.medic.model;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Emergency {
    private String time;
    private String location;
    private String type;
    private String priority;
}
