package com.maxxki.medic.model;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Equipment {
    private String name;
    private String icon;
    private String status; // online | maintenance | offline
}
