import { useState, useEffect, useCallback } from 'react';
import { api } from '../api/client';

export function useDashboard() {
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  const load = useCallback(async () => {
    try {
      const d = await api.dashboard();
      setData(d);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, [load]);

  return { data, loading, error, refresh: load };
}

export function usePatients(filter) {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    let active = true;
    api.patients(filter)
      .then(d => { if (active) setPatients(d); })
      .catch(console.error);
    return () => { active = false; };
  }, [filter]);

  return patients;
}
