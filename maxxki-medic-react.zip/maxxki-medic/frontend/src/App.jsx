import { useState, useEffect } from 'react';
import { useDashboard, usePatients } from './hooks/useDashboard';

// ─── Helpers ──────────────────────────────────────────────────────────────────
const priorityStyles = {
  high:   'border border-red-600 bg-red-900/20 text-red-400',
  medium: 'border border-yellow-500 bg-yellow-900/20 text-yellow-400',
  low:    'border border-green-500 bg-green-900/20 text-green-400',
};
const statusColor = { online: 'text-green-400', maintenance: 'text-yellow-400', offline: 'text-red-400' };
const orStatusColor = { active: 'text-green-400', prep: 'text-yellow-400', scheduled: 'text-blue-300', standby: 'text-gray-400' };
const orStatusLabel = { active: '● AKTIV', prep: '◐ VORBEREITUNG', scheduled: '○ GEPLANT', standby: '○ STANDBY' };

function useClock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return time;
}

function shift(hour) {
  if (hour >= 6  && hour < 14) return 'FRÜHSCHICHT';
  if (hour >= 14 && hour < 22) return 'SPÄTSCHICHT';
  return 'NACHTSCHICHT';
}

// ─── Panel Shell ──────────────────────────────────────────────────────────────
function Panel({ title, badge, children, accent = 'border-t-blue-400', className = '' }) {
  return (
    <div className={`bg-[#132f4c] border border-[#1e4976] rounded-lg p-5 relative overflow-hidden
                     hover:border-[#00a8e8] hover:shadow-[0_0_20px_rgba(0,168,232,0.25)] transition-all duration-300
                     ${className}`}>
      <div className={`absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-[#00a8e8] to-transparent`} />
      <div className="flex justify-between items-center mb-4 font-mono text-xs font-bold text-[#00a8e8] uppercase tracking-widest">
        {title}
        {badge && (
          <span className="bg-blue-500/20 border border-[#00a8e8] px-3 py-1 rounded-full text-[0.65rem]">
            {badge}
          </span>
        )}
      </div>
      {children}
    </div>
  );
}

// ─── Emergency Panel ──────────────────────────────────────────────────────────
function EmergencyPanel({ emergencies = [] }) {
  return (
    <div className="bg-gradient-to-br from-[#1a0d0d] to-[#132f4c] border border-red-700 rounded-lg p-5 relative overflow-hidden
                    hover:shadow-[0_0_20px_rgba(211,47,47,0.3)] transition-all duration-300">
      <div className="absolute top-0 left-0 w-full h-[3px] bg-gradient-to-r from-red-600 to-transparent" />
      <div className="flex justify-between items-center mb-4 font-mono text-xs font-bold text-red-400 uppercase tracking-widest">
        🚨 EMERGENCY ALERTS
        <span className="bg-red-900/40 border border-red-600 px-3 py-1 rounded-full text-[0.65rem]">
          {emergencies.length} AKTIV
        </span>
      </div>
      <div className="flex flex-col gap-3">
        {emergencies.map((e, i) => (
          <div key={i} className="bg-red-900/10 border-l-4 border-red-600 p-3 rounded animate-pulse">
            <div className="font-mono text-red-500 font-bold text-sm mb-1">{e.time} — {e.type}</div>
            <div className="text-blue-300 text-xs">{e.location}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Stats Grid ───────────────────────────────────────────────────────────────
function StatsGrid({ data }) {
  const stats = [
    { value: data?.criticalCount  ?? '—', label: 'Kritisch',    cls: 'text-red-500' },
    { value: data?.stableCount    ?? '—', label: 'Stabil',      cls: 'text-yellow-400' },
    { value: data?.dischargeReady ?? '—', label: 'Entlassung',  cls: 'text-green-400' },
    { value: data?.totalPatients  ?? '—', label: 'Gesamt',      cls: 'text-blue-400' },
  ];
  return (
    <Panel title="📊 Patient Overview">
      <div className="grid grid-cols-2 gap-3">
        {stats.map(s => (
          <div key={s.label} className="bg-blue-500/5 border border-[#1e4976] rounded-lg p-3 text-center">
            <div className={`text-4xl font-black font-mono ${s.cls}`}>{s.value}</div>
            <div className="text-[0.65rem] text-blue-300 uppercase tracking-widest mt-1">{s.label}</div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

// ─── Departments ──────────────────────────────────────────────────────────────
function Departments({ departments = [] }) {
  return (
    <Panel title="🏢 Abteilungen Status">
      <div className="flex flex-col gap-2">
        {departments.map(d => {
          const pct = Math.round((d.current / d.max) * 100);
          const fill = pct > 80 ? 'bg-red-500' : pct > 60 ? 'bg-yellow-500' : 'bg-green-500';
          return (
            <div key={d.name} className="flex items-center justify-between p-2 rounded border border-white/5 bg-white/[0.02]">
              <span className="font-semibold text-sm text-slate-100">{d.name}</span>
              <div className="flex items-center gap-2">
                <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all duration-500 ${fill}`} style={{ width: `${pct}%` }} />
                </div>
                <span className="font-mono text-xs text-blue-300 w-12 text-right">{d.current}/{d.max}</span>
              </div>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

// ─── Patient Cards ────────────────────────────────────────────────────────────
function PatientCard({ p }) {
  return (
    <div className="bg-blue-500/5 border border-[#1e4976] rounded-lg p-4 hover:border-[#00a8e8]
                    hover:shadow-[0_0_15px_rgba(0,168,232,0.2)] hover:-translate-y-0.5 transition-all duration-300">
      <div className="flex justify-between items-center mb-3">
        <span className="font-mono font-bold text-[#00a8e8] text-sm">{p.id}</span>
        <span className={`px-2 py-0.5 rounded-full text-[0.65rem] font-bold ${priorityStyles[p.priority]}`}>
          {p.priority.toUpperCase()}
        </span>
      </div>
      <div className="text-sm text-blue-200 leading-relaxed mb-2">
        <strong className="text-white">{p.name}</strong> ({p.age}J)<br />
        <span className="text-blue-300">{p.condition}</span>
      </div>
      <div className="flex gap-4 pt-2 border-t border-white/10">
        {[['HR', p.hr], ['BP', p.bp], ['Temp', p.temp]].map(([l, v]) => (
          <div key={l} className="text-xs">
            <span className="text-blue-400">{l}: </span>
            <span className="font-mono font-bold text-green-400">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function PatientTracking() {
  const [filter, setFilter] = useState('all');
  const patients = usePatients(filter);

  return (
    <div className="bg-[#132f4c] border border-[#1e4976] rounded-lg p-6 min-h-[600px]
                    hover:border-[#00a8e8] transition-all duration-300">
      <div className="flex justify-between items-center mb-6 pb-4 border-b-2 border-[#1e4976]">
        <h2 className="text-xl font-bold font-mono text-white tracking-widest">PATIENT TRACKING</h2>
        <div className="flex gap-2">
          {['all', 'critical', 'stable'].map(f => (
            <button key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-all duration-200
                ${filter === f
                  ? 'bg-[#00a8e8] text-[#0a1929] border-[#00a8e8]'
                  : 'bg-blue-500/10 border border-[#1e4976] text-white hover:bg-[#00a8e8] hover:text-[#0a1929]'
                } border`}
            >
              {f === 'all' ? 'Alle' : f === 'critical' ? 'Kritisch' : 'Stabil'}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {patients.map(p => <PatientCard key={p.id} p={p} />)}
      </div>
    </div>
  );
}

// ─── OR Schedule ──────────────────────────────────────────────────────────────
function OrSchedule({ schedule = [] }) {
  return (
    <Panel title="⚕️ OP-Plan" badge="5 HEUTE">
      <div className="flex flex-col gap-2">
        {schedule.map((or, i) => (
          <div key={i} className="bg-blue-500/8 border-l-4 border-[#00a8e8] px-3 py-3 rounded grid grid-cols-[72px_1fr_auto] gap-2 items-center">
            <span className="font-mono font-bold text-[#00a8e8] text-sm">{or.time}</span>
            <div>
              <div className="text-sm text-white">{or.procedure}</div>
              <div className="text-xs text-blue-300">{or.surgeon}</div>
            </div>
            <span className={`text-xs font-bold font-mono ${orStatusColor[or.status]}`}>
              {orStatusLabel[or.status]}
            </span>
          </div>
        ))}
      </div>
    </Panel>
  );
}

// ─── Equipment ────────────────────────────────────────────────────────────────
function Equipment({ equipment = [] }) {
  return (
    <Panel title="🔧 Equipment Status">
      <div className="grid grid-cols-3 gap-2">
        {equipment.map(e => (
          <div key={e.name} className="bg-blue-500/5 border border-[#1e4976] rounded-lg p-3 text-center
                                       hover:border-[#00a8e8] transition-colors">
            <div className="text-2xl mb-2">{e.icon}</div>
            <div className="text-[0.65rem] text-blue-300 mb-1">{e.name}</div>
            <div className={`text-xs font-bold ${statusColor[e.status]}`}>
              {e.status === 'online' ? '● ONLINE' : e.status === 'maintenance' ? '⚠ WARTUNG' : '○ OFFLINE'}
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

// ─── App Root ─────────────────────────────────────────────────────────────────
export default function App() {
  const { data, loading, error } = useDashboard();
  const time = useClock();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a1929] flex items-center justify-center">
        <div className="text-[#00a8e8] font-mono text-xl animate-pulse tracking-widest">
          MAXXKI MEDIC — LOADING…
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#0a1929] flex items-center justify-center">
        <div className="text-red-400 font-mono text-lg">
          ⚠ API FEHLER: {error}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a1929] text-[#e3f2fd] p-5"
         style={{
           backgroundImage: `linear-gradient(rgba(0,168,232,0.03) 1px, transparent 1px),
                             linear-gradient(90deg, rgba(0,168,232,0.03) 1px, transparent 1px)`,
           backgroundSize: '50px 50px',
         }}>
      <div className="max-w-[1800px] mx-auto">

        {/* Header */}
        <header className="bg-gradient-to-br from-[#132f4c] to-[#1a3a52] border-2 border-[#1e4976]
                           border-l-[5px] border-l-[#00a8e8] px-10 py-6 font-mono font-bold tracking-widest
                           flex justify-between items-center rounded-lg shadow-[0_8px_32px_rgba(0,168,232,0.2)]
                           relative overflow-hidden mb-6">
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-[#00a8e8] to-transparent animate-[scanline_3s_linear_infinite]" />
          <div className="flex items-center gap-4 text-3xl">
            <div className="w-10 h-10 bg-[#00a8e8] rounded-lg flex items-center justify-center text-xl">🏥</div>
            MAXXKI MEDIC
          </div>
          <div className="flex gap-8 text-xs font-semibold">
            <div className="text-right">
              <div className="text-blue-300 mb-1">SYSTEM STATUS</div>
              <div className="text-green-400 font-mono text-lg">{data?.systemStatus ?? 'ONLINE'}</div>
            </div>
            <div className="text-right">
              <div className="text-blue-300 mb-1">UPTIME</div>
              <div className="text-green-400 font-mono text-lg">{data?.uptime ?? '99.8%'}</div>
            </div>
          </div>
        </header>

        {/* Main 3-column grid */}
        <div className="grid grid-cols-1 xl:grid-cols-[380px_1fr_380px] gap-5 mb-5">
          {/* Left */}
          <div className="flex flex-col gap-5">
            <EmergencyPanel emergencies={data?.emergencies} />
            <StatsGrid data={data} />
            <Departments departments={data?.departments} />
          </div>

          {/* Center */}
          <PatientTracking />

          {/* Right */}
          <div className="flex flex-col gap-5">
            <OrSchedule schedule={data?.orSchedule} />
            <Equipment equipment={data?.equipment} />
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-[#132f4c] border border-[#1e4976] border-t-2 border-t-[#00a8e8]
                           px-8 py-5 font-mono flex justify-between items-center rounded-lg">
          <div className="flex gap-10 text-sm">
            {[
              ['STANDORT', data?.location ?? 'Klinikum Regensburg'],
              ['STATION',  'ZENTRALES OPS CENTER'],
              ['SCHICHT',  shift(time.getHours())],
            ].map(([label, value]) => (
              <div key={label}>
                <div className="text-blue-400 text-[0.65rem] mb-1">{label}</div>
                <div className="text-[#00a8e8] font-bold">{value}</div>
              </div>
            ))}
          </div>
          <div className="text-[#00a8e8] text-2xl font-bold">
            {time.toLocaleTimeString('de-DE')}
          </div>
        </footer>
      </div>
    </div>
  );
}
