const BASE = '/api';

export const api = {
  dashboard:   () => fetch(`${BASE}/dashboard`).then(r => r.json()),
  patients:    (filter = 'all') => fetch(`${BASE}/patients?filter=${filter}`).then(r => r.json()),
  departments: () => fetch(`${BASE}/departments`).then(r => r.json()),
  emergencies: () => fetch(`${BASE}/emergencies`).then(r => r.json()),
  orSchedule:  () => fetch(`${BASE}/or-schedule`).then(r => r.json()),
  equipment:   () => fetch(`${BASE}/equipment`).then(r => r.json()),
};
