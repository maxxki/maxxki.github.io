# maxxki/plugins/datadivision.py (Auszug)
from ..mapping_loader import MappingLoader

class DataDivisionConverter:
    def __init__(self):
        self.mapping = MappingLoader().rules

    def convert(self, stmt):
        content = stmt.content.strip()
        parts = content.split()

        if "DS" in parts:
            if "F" in parts:
                cobol = self.mapping["data_definitions"]["DS"]["F"]
                return type("R", (), {"converted": f"01 {parts[0]} {cobol}."})()

        return type("R", (), {"converted": f"* Unhandled: {content}"})()