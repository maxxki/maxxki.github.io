# maxxki/parser.py
import re
from typing import List
from .core_types import Statement, StatementType

class Parser:
    """
    Einfacher, line-basierter HLASM Parser (minimal).
    Erkennt: DS, DC, MACRO, Kommentare (Zeilen mit *), sonst Instruktionen.
    Zur späteren Ersetzung durch eine PLY- oder erweiterten Parser.
    """
    def __init__(self):
        self.comment_re = re.compile(r'^\s*\*')
        self.ds_re = re.compile(r'^\s*(\w+)\s+DS\b', re.IGNORECASE)
        self.dc_re = re.compile(r'^\s*(\w+)\s+DC\b', re.IGNORECASE)
        self.macro_re = re.compile(r'^\s*\w+\s+MACRO\b', re.IGNORECASE)
        self.mend_re = re.compile(r'^\s*MEND\b', re.IGNORECASE)

    def parse(self, source: str) -> List[Statement]:
        lines = source.splitlines()
        stmts: List[Statement] = []
        for i, raw in enumerate(lines, start=1):
            line = raw.rstrip("\n")
            s = line.strip()
            if not s:
                stype = StatementType.COMMENT
            elif self.comment_re.match(s):
                stype = StatementType.COMMENT
            elif self.ds_re.search(s) or self.dc_re.search(s):
                stype = StatementType.DATA_DEFINITION
            elif self.macro_re.search(s) or self.mend_re.search(s):
                stype = StatementType.MACRO
            else:
                stype = StatementType.MACHINE_INSTRUCTION
            stmts.append(Statement(content=line, stmt_type=stype, line_no=i))
        return stmts