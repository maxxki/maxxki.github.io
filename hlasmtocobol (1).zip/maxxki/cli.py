# maxxki/cli.py
import argparse
from pathlib import Path
from .core_converter import CoreConverter

def main():
    parser = argparse.ArgumentParser(
        prog="maxxki",
        description="HLASM to COBOL converter"
    )
    parser.add_argument("input", type=Path, help="Input HLASM file")
    parser.add_argument("-o", "--output", type=Path, help="Output COBOL file")
    parser.add_argument("--no-ml", action="store_true", help="Disable ML usage")
    args = parser.parse_args()

    source_code = args.input.read_text(encoding="utf-8")

    converter = CoreConverter(use_ml=not args.no_ml)  # ML optional
    results = converter.convert(source_code)

    converted_code = "\n".join(r.converted for r in results)

    if args.output:
        args.output.write_text(converted_code, encoding="utf-8")
        print(f"[+] COBOL code written to {args.output}")
    else:
        print(converted_code)