# maxxki/__init__.py
"""
MAXXKI – HLASM → COBOL Converter (Prototype)
"""
__version__ = "0.1.0"