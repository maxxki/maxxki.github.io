# maxxki/mapping_loader.py
import yaml
from pathlib import Path

class MappingLoader:
    def __init__(self, path: str | None = None):
        if path is None:
            path = Path(__file__).parent / "mappings" / "hlasm_to_cobol.yml"
        self._path = Path(path)
        self._data = self._load()

    def _load(self) -> dict:
        with open(self._path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    @property
    def rules(self) -> dict:
        return self._data