# maxxki/core_converter.py (Enhanced Version)
"""
Erweiterte Core Converter-Implementierung mit ML-Integration und Plugin-System.
Enterprise-ready mit Performance-Optimierungen und detailliertem Reporting.
"""

import logging
import time
from typing import List, Dict, Any, Optional, Union
from dataclasses import dataclass
from pathlib import Path
import json

from .service_registry import ServiceRegistry
from .core_types import Statement, StatementType
from .plugins.base import ConverterPlugin
from .plugins.datadivision import DataDivisionConverter
from .plugins.instructions import InstructionConverter
from .plugins.macros import MacroConverter


@dataclass
class ConversionReport:
    """Detaillierter Bericht über die Konvertierung."""
    total_statements: int
    converted_statements: int
    failed_statements: int
    ml_conversions: int
    rule_conversions: int
    plugin_conversions: Dict[str, int]
    processing_time: float
    confidence_scores: List[float]
    errors: List[str]
    warnings: List[str]
    
    @property
    def success_rate(self) -> float:
        """Erfolgsrate der Konvertierung."""
        if self.total_statements == 0:
            return 0.0
        return self.converted_statements / self.total_statements
    
    @property
    def average_confidence(self) -> float:
        """Durchschnittliche Konfidenz."""
        if not self.confidence_scores:
            return 0.0
        return sum(self.confidence_scores) / len(self.confidence_scores)


class CoreConverter:
    """
    Erweiterte Kern-Konvertierung mit ML-Unterstützung und Plugin-System.
    
    Features:
    - Hybrid-Konvertierung (Regelbasiert + ML)
    - Plugin-System für erweiterte Konvertierungen
    - Performance-Monitoring
    - Detailliertes Reporting
    - Batch-Processing
    - Error Recovery
    """
    
    def __init__(self, use_ml: bool = True, plugins: Optional[List[str]] = None):
        """
        Initialisiert den Core Converter.
        
        Args:
            use_ml: ML-Unterstützung aktivieren
            plugins: Liste der zu ladenden Plugins
        """
        self.logger = logging.getLogger(__name__)
        
        # Services laden
        self.parser = ServiceRegistry.get("parser")
        
        # ML Model optional laden
        self.ml_model = None
        if use_ml:
            try:
                self.ml_model = ServiceRegistry.get("ml_model")
                self.logger.info("ML-Model erfolgreich geladen")
            except Exception as e:
                self.logger.warning(f"ML-Model konnte nicht geladen werden: {e}")
                self.ml_model = None
        
        # Plugin System initialisieren
        self.plugins: Dict[str, ConverterPlugin] = {}
        self._load_plugins(plugins or ["datadivision", "instructions", "macros"])
        
        # Statistics
        self.conversion_stats = {
            "total_conversions": 0,
            "successful_conversions": 0,
            "failed_conversions": 0,
            "ml_used": 0,
            "plugins_used": 0
        }
    
    def _load_plugins(self, plugin_names: List[str]) -> None:
        """Lädt Converter-Plugins."""
        plugin_classes = {
            "datadivision": DataDivisionConverter,
            "instructions": InstructionConverter,
            "macros": MacroConverter
        }
        
        for plugin_name in plugin_names:
            if plugin_name in plugin_classes:
                try:
                    plugin_class = plugin_classes[plugin_name]
                    self.plugins[plugin_name] = plugin_class()
                    self.logger.info(f"Plugin '{plugin_name}' geladen")
                except Exception as e:
                    self.logger.error(f"Fehler beim Laden von Plugin '{plugin_name}': {e}")
            else:
                self.logger.warning(f"Unbekanntes Plugin: {plugin_name}")
    
    def convert(self, source_code: str, output_format: str = "cobol") -> ConversionReport:
        """
        Konvertiert HLASM-Quellcode zu COBOL.
        
        Args:
            source_code: HLASM-Quellcode als String
            output_format: Ziel-Format ("cobol", "json", "xml")
            
        Returns:
            ConversionReport mit Ergebnissen und Statistiken
        """
        start_time = time.time()
        self.logger.info(f"Starte Konvertierung ({len(source_code)} Zeichen)")
        
        # Parse HLASM Code
        try:
            statements = self.parser.parse(source_code)
        except Exception as e:
            return ConversionReport(
                total_statements=0,
                converted_statements=0,
                failed_statements=0,
                ml_conversions=0,
                rule_conversions=0,
                plugin_conversions={},
                processing_time=time.time() - start_time,
                confidence_scores=[],
                errors=[f"Parse-Fehler: {str(e)}"],
                warnings=[]
            )
        
        # Konvertiere Statements
        results = []
        errors = []
        warnings = []
        confidence_scores = []
        plugin_stats = {plugin: 0 for plugin in self.plugins}
        ml_count = 0
        rule_count = 0
        
        for stmt in statements:
            try:
                result = self._convert_statement(stmt)
                results.append(result)
                
                # Statistics
                if hasattr(result, 'conversion_method'):
                    if result.conversion_method == 'ml':
                        ml_count += 1
                    elif result.conversion_method == 'rule':
                        rule_count += 1
                    elif result.conversion_method in plugin_stats:
                        plugin_stats[result.conversion_method] += 1
                
                if hasattr(result, 'confidence_score'):
                    confidence_scores.append(result.confidence_score)
                
            except Exception as e:
                error_msg = f"Konvertierungsfehler bei Statement '{stmt.content[:50]}...': {str(e)}"
                errors.append(error_msg)
                self.logger.error(error_msg)
                
                # Fallback: Kommentar erstellen
                fallback = type("FallbackResult", (), {
                    "converted": f"*> FEHLER: {stmt.content}",
                    "conversion_method": "fallback",
                    "confidence_score": 0.0
                })()
                results.append(fallback)
        
        # Parser warnings
        if hasattr(self.parser, 'get_warnings'):
            warnings.extend(self.parser.get_warnings())
        
        processing_time = time.time() - start_time
        
        # Erstelle Bericht
        report = ConversionReport(
            total_statements=len(statements),
            converted_statements=len([r for r in results if not r.converted.startswith("*> FEHLER")]),
            failed_statements=len([r for r in results if r.converted.startswith("*> FEHLER")]),
            ml_conversions=ml_count,
            rule_conversions=rule_count,
            plugin_conversions=plugin_stats,
            processing_time=processing_time,
            confidence_scores=confidence_scores,
            errors=errors,
            warnings=warnings
        )
        
        self.logger.info(f"Konvertierung abgeschlossen: {report.success_rate:.1%} Erfolg in {processing_time:.2f}s")
        
        # Update global stats
        self.conversion_stats["total_conversions"] += 1
        self.conversion_stats["successful_conversions"] += 1 if report.success_rate > 0.5 else 0
        
        return report
    
    def _convert_statement(self, stmt: Statement) -> Any:
        """
        Konvertiert ein einzelnes Statement mit Hybrid-Strategie.
        
        Strategy:
        1. Plugin-basierte Konvertierung (spezifisch)
        2. ML-basierte Konvertierung (komplex)
        3. Fallback-Konvertierung (generisch)
        """
        # 1. Plugin-basierte Konvertierung
        for plugin_name, plugin in self.plugins.items():
            if plugin.can_handle(stmt):
                try:
                    result = plugin.convert(stmt)
                    if result and hasattr(result, 'converted') and result.converted:
                        # Markiere Konvertierungsmethode
                        result.conversion_method = plugin_name
                        if not hasattr(result, 'confidence_score'):
                            result.confidence_score = 0.85  # High confidence for plugin-based
                        return result
                except Exception as e:
                    self.logger.warning(f"Plugin '{plugin_name}' Fehler: {e}")
                    continue
        
        # 2. ML-basierte Konvertierung für komplexe Patterns
        if self.ml_model and self._should_use_ml(stmt):
            try:
                result = self.ml_model.convert_statement(stmt)
                if result and result.confidence_score > 0.3:  # Minimum confidence threshold
                    result.conversion_method = 'ml'
                    return result
            except Exception as e:
                self.logger.warning(f"ML-Konvertierung fehlgeschlagen: {e}")
        
        # 3. Fallback: Basis-Regelkonvertierung
        return self._rule_based_fallback(stmt)
    
    def _should_use_ml(self, stmt: Statement) -> bool:
        """Entscheidet ob ML für Statement verwendet werden soll."""
        if not self.ml_model:
            return False
        
        # ML für komplexe/unbekannte Patterns
        complex_indicators = [
            "MACRO", "DSECT", "USING", "EQU", "ORG", "@", "SVC",
            "(", "SAVE", "RETURN", "CALL", "WTO", "OPEN", "CLOSE"
        ]
        
        content_upper = stmt.content.upper()
        return any(indicator in content_upper for indicator in complex_indicators)
    
    def _rule_based_fallback(self, stmt: Statement) -> Any:
        """Basis-Regelkonvertierung als Fallback."""
        content = stmt.content.strip()
        
        # Einfache Patterns
        if stmt.stmt_type == StatementType.COMMENT:
            converted = f"*> {content[1:].strip()}"  # Remove leading *
        elif stmt.stmt_type == StatementType.DATA_DEFINITION:
            converted = f"*> Data Definition: {content}"
        elif stmt.stmt_type == StatementType.INSTRUCTION:
            converted = f"*> Instruction: {content}"
        elif stmt.stmt_type == StatementType.MACRO:
            converted = f"*> Macro: {content}"
        else:
            converted = f"*> Unknown: {content}"
        
        return type("RuleFallback", (), {
            "converted": converted,
            "conversion_method": "rule",
            "confidence_score": 0.2
        })()
    
    def convert_file(self, input_path: Union[str, Path], output_path: Optional[Union[str, Path]] = None) -> ConversionReport:
        """
        Konvertiert HLASM-Datei zu COBOL.
        
        Args:
            input_path: Eingabe-Datei
            output_path: Ausgabe-Datei (optional)
            
        Returns:
            ConversionReport
        """
        input_path = Path(input_path)
        
        if not input_path.exists():
            raise FileNotFoundError(f"Eingabe-Datei nicht gefunden: {input_path}")
        
        # Lese Quellcode
        try:
            source_code = input_path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            # Fallback für andere Encodings
            source_code = input_path.read_text(encoding='cp1252')
        
        # Konvertiere
        report = self.convert(source_code)
        
        # Schreibe Ausgabe
        if output_path:
            output_path = Path(output_path)
            converted_code = self.generate_cobol_output(report, source_code)
            
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(converted_code, encoding='utf-8')
            
            self.logger.info(f"COBOL-Code geschrieben nach: {output_path}")
        
        return report
    
    def generate_cobol_output(self, report: ConversionReport, original_code: str) -> str:
        """
        Generiert formatierten COBOL-Code aus Konvertierungsergebnissen.
        
        Args:
            report: Konvertierungsbericht
            original_code: Original HLASM-Code
            
        Returns:
            Formatierter COBOL-Code
        """
        # Parse original wieder für Results
        statements = self.parser.parse(original_code)
        cobol_lines = []
        
        # COBOL Header
        cobol_lines.extend([
            "       IDENTIFICATION DIVISION.",
            "       PROGRAM-ID. CONVERTED-PROGRAM.",
            "       AUTHOR. MAXXKI-CONVERTER.",
            f"      * Converted from HLASM - {report.success_rate:.1%} success rate",
            f"      * Processing time: {report.processing_time:.2f} seconds",
            "       ",
            "       DATA DIVISION.",
            "       WORKING-STORAGE SECTION.",
            "       "
        ])
        
        # Konvertierte Statements
        for i, stmt in enumerate(statements):
            try:
                result = self._convert_statement(stmt)
                if result and hasattr(result, 'converted'):
                    cobol_lines.append(result.converted)
                else:
                    cobol_lines.append(f"*> Unconverted: {stmt.content}")
            except:
                cobol_lines.append(f"*> Error: {stmt.content}")
        
        # COBOL Footer
        cobol_lines.extend([
            "       ",
            "       PROCEDURE DIVISION.",
            "       MAIN-LOGIC.",
            "           DISPLAY 'Program converted from HLASM'.",
            "           STOP RUN.",
            "       "
        ])
        
        return "\n".join(cobol_lines)
    
    def batch_convert(self, file_patterns: List[str], output_dir: Union[str, Path]) -> Dict[str, ConversionReport]:
        """
        Batch-Konvertierung mehrerer Dateien.
        
        Args:
            file_patterns: Glob-Patterns für Eingabedateien
            output_dir: Ausgabeverzeichnis
            
        Returns:
            Dictionary mit Datei -> ConversionReport Mapping
        """
        from glob import glob
        
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        results = {}
        
        # Sammle alle Dateien
        all_files = []
        for pattern in file_patterns:
            all_files.extend(glob(pattern))