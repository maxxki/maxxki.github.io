# maxxki/ml/local_converter.py
"""
Lokale ML-gestützte HLASM-zu-COBOL Konvertierung mit quantisierten HuggingFace-Modellen.
Enterprise-ready Implementation mit Fallback-Strategien und Performance-Optimierungen.
"""

import logging
import os
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum
import json

try:
    import torch
    from transformers import (
        AutoTokenizer, 
        AutoModelForCausalLM, 
        AutoModelForSeq2SeqLM,
        pipeline,
        Pipeline
    )
    from accelerate import init_empty_weights, load_checkpoint_and_dispatch
    HF_AVAILABLE = True
except ImportError:
    HF_AVAILABLE = False
    torch = None
    Pipeline = None

from ..core_types import Statement, StatementType
from ..mapping_loader import MappingLoader


class ModelType(Enum):
    """Unterstützte Modell-Typen für Code-Konvertierung."""
    CODET5_PLUS = "Salesforce/codet5p-770m"
    CODEGEN_350M = "Salesforce/codegen-350M-mono"
    CODEGEN_2B = "Salesforce/codegen-2B-mono"
    STARCODER_BASE = "bigcode/starcoder-1b"
    LLAMA_CODE = "codellama/CodeLlama-7b-Instruct-hf"
    

@dataclass
class ConversionResult:
    """Ergebnis einer ML-Konvertierung."""
    original_code: str
    converted_code: str
    confidence_score: float
    processing_time: float
    model_used: str
    fallback_used: bool = False
    

class LocalMLConverter:
    """
    Lokaler ML-Konverter für HLASM-zu-COBOL mit quantisierten Modellen.
    
    Features:
    - Automatische Model-Quantisierung (4bit, 8bit, 16bit)
    - GPU/CPU Fallback
    - Batch-Processing
    - Memory-efficient Loading
    - Enterprise Caching
    """
    
    def __init__(
        self, 
        model_type: ModelType = ModelType.CODET5_PLUS,
        quantization_bits: int = 8,
        max_memory_gb: float = 16.0,
        cache_dir: Optional[str] = None,
        device: Optional[str] = None
    ):
        """
        Initialisiert den ML-Konverter.
        
        Args:
            model_type: Zu verwendender Modell-Typ
            quantization_bits: 4, 8, oder 16 Bit Quantisierung
            max_memory_gb: Maximaler RAM-Verbrauch
            cache_dir: Verzeichnis für Model-Cache
            device: Ziel-Device ('cuda', 'cpu', 'auto')
        """
        self.logger = logging.getLogger(__name__)
        
        if not HF_AVAILABLE:
            raise ImportError(
                "HuggingFace transformers nicht installiert. "
                "Führe aus: pip install transformers torch accelerate bitsandbytes"
            )
        
        self.model_type = model_type
        self.quantization_bits = quantization_bits
        self.max_memory_gb = max_memory_gb
        self.cache_dir = cache_dir or os.getenv("MAXXKI_MODEL_CACHE", "./models")
        self.device = device or self._auto_detect_device()
        
        # Fallback für regelbasierte Konvertierung
        self.rule_mapping = MappingLoader().rules
        
        # Model Pipeline
        self._pipeline: Optional[Pipeline] = None
        self._tokenizer = None
        self._model = None
        
        # Performance Tracking
        self._conversion_stats = {
            "total_conversions": 0,
            "ml_conversions": 0,
            "rule_conversions": 0,
            "failed_conversions": 0,
            "avg_processing_time": 0.0
        }
        
        # Lazy Loading - Model wird erst bei Bedarf geladen
        self._model_loaded = False
        
    def _auto_detect_device(self) -> str:
        """Automatische Device-Erkennung."""
        if torch and torch.cuda.is_available():
            gpu_memory = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            if gpu_memory >= 8:
                self.logger.info(f"CUDA-GPU erkannt: {gpu_memory:.1f}GB VRAM")
                return "cuda"
        
        self.logger.info("Fallback auf CPU-Verarbeitung")
        return "cpu"
    
    def _ensure_model_loaded(self) -> None:
        """Lazy Loading des ML-Models."""
        if self._model_loaded:
            return
            
        self.logger.info(f"Lade Modell: {self.model_type.value}")
        start_time = time.time()
        
        try:
            self._load_model()
            self._model_loaded = True
            load_time = time.time() - start_time
            self.logger.info(f"Modell geladen in {load_time:.2f}s")
            
        except Exception as e:
            self.logger.error(f"Fehler beim Laden des Modells: {e}")
            raise RuntimeError(f"Model loading failed: {e}")
    
    def _load_model(self) -> None:
        """Lädt und konfiguriert das quantisierte Modell."""
        model_name = self.model_type.value
        
        # Quantisierung-Konfiguration
        quantization_config = self._get_quantization_config()
        
        try:
            # Tokenizer laden
            self._tokenizer = AutoTokenizer.from_pretrained(
                model_name,
                cache_dir=self.cache_dir,
                trust_remote_code=True
            )
            
            # Padding Token setzen falls nicht vorhanden
            if self._tokenizer.pad_token is None:
                self._tokenizer.pad_token = self._tokenizer.eos_token
            
            # Model laden mit Quantisierung
            if "codet5" in model_name.lower():
                model_class = AutoModelForSeq2SeqLM
            else:
                model_class = AutoModelForCausalLM
                
            self._model = model_class.from_pretrained(
                model_name,
                cache_dir=self.cache_dir,
                quantization_config=quantization_config,
                device_map="auto" if self.device == "auto" else None,
                torch_dtype=torch.float16 if self.quantization_bits >= 8 else torch.float32,
                trust_remote_code=True,
                low_cpu_mem_usage=True
            )
            
            if self.device != "auto":
                self._model = self._model.to(self.device)
            
            # Pipeline erstellen
            task = "text2text-generation" if "t5" in model_name.lower() else "text-generation"
            self._pipeline = pipeline(
                task,
                model=self._model,
                tokenizer=self._tokenizer,
                device=0 if self.device == "cuda" else -1
            )
            
        except Exception as e:
            self.logger.error(f"Fehler bei Model-Loading: {e}")
            # Fallback auf kleineres Modell
            if self.model_type != ModelType.CODEGEN_350M:
                self.logger.warning("Fallback auf kleineres Modell")
                self.model_type = ModelType.CODEGEN_350M
                self._load_model()
            else:
                raise
    
    def _get_quantization_config(self) -> Dict:
        """Erstellt Quantisierung-Konfiguration basierend auf verfügbarem Speicher."""
        if self.quantization_bits == 4:
            from transformers import BitsAndBytesConfig
            return BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4"
            )
        elif self.quantization_bits == 8:
            from transformers import BitsAndBytesConfig
            return BitsAndBytesConfig(
                load_in_8bit=True,
                llm_int8_threshold=6.0
            )
        else:
            return {}
    
    def convert_statement(self, statement: Statement) -> ConversionResult:
        """
        Konvertiert ein einzelnes HLASM-Statement zu COBOL.
        
        Args:
            statement: HLASM Statement
            
        Returns:
            ConversionResult mit konvertiertem Code
        """
        start_time = time.time()
        self._conversion_stats["total_conversions"] += 1
        
        # 1. Versuche regelbasierte Konvertierung zuerst
        rule_result = self._try_rule_based_conversion(statement)
        if rule_result:
            processing_time = time.time() - start_time
            self._conversion_stats["rule_conversions"] += 1
            return ConversionResult(
                original_code=statement.content,
                converted_code=rule_result,
                confidence_score=0.95,  # Hohe Konfidenz für regelbasiert
                processing_time=processing_time,
                model_used="rule_based",
                fallback_used=False
            )
        
        # 2. ML-Konvertierung für komplexe Patterns
        if self._is_complex_pattern(statement):
            try:
                self._ensure_model_loaded()
                ml_result = self._ml_convert(statement.content)
                processing_time = time.time() - start_time
                self._conversion_stats["ml_conversions"] += 1
                
                return ConversionResult(
                    original_code=statement.content,
                    converted_code=ml_result["converted"],
                    confidence_score=ml_result["confidence"],
                    processing_time=processing_time,
                    model_used=self.model_type.value,
                    fallback_used=False
                )
                
            except Exception as e:
                self.logger.warning(f"ML-Konvertierung fehlgeschlagen: {e}")
        
        # 3. Fallback: Kommentar-Konvertierung
        processing_time = time.time() - start_time
        self._conversion_stats["failed_conversions"] += 1
        
        return ConversionResult(
            original_code=statement.content,
            converted_code=f"*> TODO: Konvertiere '{statement.content.strip()}'",
            confidence_score=0.1,
            processing_time=processing_time,
            model_used="fallback",
            fallback_used=True
        )
    
    def _try_rule_based_conversion(self, statement: Statement) -> Optional[str]:
        """Versucht regelbasierte Konvertierung."""
        content = statement.content.strip()
        parts = content.split()
        
        if len(parts) < 2:
            return None
        
        # Data Definition Statements
        if statement.stmt_type == StatementType.DATA_DEFINITION:
            return self._convert_data_definition(parts)
        
        # Instructions
        if len(parts) >= 2:
            instruction = parts[1].upper()
            if instruction in self.rule_mapping.get("instructions", {}):
                return self._convert_instruction(parts)
        
        return None
    
    def _convert_data_definition(self, parts: List[str]) -> Optional[str]:
        """Konvertiert Data Definition Statements."""
        if len(parts) < 3:
            return None
            
        name = parts[0]
        op = parts[1].upper()
        operand = parts[2].upper()
        
        dd_rules = self.rule_mapping.get("data_definitions", {})
        
        if op in dd_rules and operand in dd_rules[op]:
            cobol_def = dd_rules[op][operand]
            
            # Handle dynamic values
            if len(parts) > 3 and "{value}" in cobol_def:
                value = parts[3].strip("'\"")
                cobol_def = cobol_def.replace("{value}", value)
            
            if "{length}" in cobol_def:
                # Extract length from CL8, PIC X(10), etc.
                import re
                length_match = re.search(r'(\d+)', operand)
                if length_match:
                    length = length_match.group(1)
                    cobol_def = cobol_def.replace("{length}", length)
            
            return f"       01 {name:<30} {cobol_def}."
        
        return None
    
    def _convert_instruction(self, parts: List[str]) -> Optional[str]:
        """Konvertiert Instructions."""
        if len(parts) < 3:
            return None
            
        instruction = parts[1].upper()
        operands = " ".join(parts[2:])
        
        instr_rules = self.rule_mapping.get("instructions", {})
        
        if instruction in instr_rules:
            template = instr_rules[instruction]
            
            # Simple operand parsing
            if "," in operands:
                ops = [op.strip() for op in operands.split(",")]
                if len(ops) >= 2:
                    result = template.replace("{src}", ops[0]).replace("{dst}", ops[1])
                    return f"           {result}"
                    
            elif instruction in ["B", "BR"]:  # Branch instructions
                result = template.replace("{label}", operands.strip())
                return f"           {result}"
        
        return None
    
    def _is_complex_pattern(self, statement: Statement) -> bool:
        """Bestimmt ob Statement komplex genug für ML-Verarbeitung ist."""
        content = statement.content.strip()
        
        # Komplexe Patterns, die ML benötigen
        complex_indicators = [
            "MACRO",           # Macro definitions
            "DSECT",           # Data sections
            "USING",           # Base register usage
            "EQU",             # Equate statements
            "ORG",             # Origin statements
            "@",               # System calls
            "SVC",             # Supervisor calls
            "(",               # Complex addressing
            "SAVE",            # Register save/restore
            "RETURN"
        ]
        
        return any(indicator in content.upper() for indicator in complex_indicators)
    
    def _ml_convert(self, hlasm_code: str) -> Dict[str, Union[str, float]]:
        """Führt ML-basierte Konvertierung durch."""
        prompt = self._build_conversion_prompt(hlasm_code)
        
        try:
            # Generation mit konfigurierten Parametern
            result = self._pipeline(
                prompt,
                max_length=256,
                num_return_sequences=1,
                temperature=0.3,  # Niedrig für deterministische Ergebnisse
                do_sample=True,
                pad_token_id=self._tokenizer.eos_token_id
            )
            
            generated_text = result[0]['generated_text']
            converted_cobol = self._extract_cobol_from_generation(generated_text, prompt)
            confidence = self._calculate_confidence(converted_cobol)
            
            return {
                "converted": converted_cobol,
                "confidence": confidence
            }
            
        except Exception as e:
            self.logger.error(f"ML-Generation fehlgeschlagen: {e}")
            raise
    
    def _build_conversion_prompt(self, hlasm_code: str) -> str:
        """Erstellt optimalen Prompt für Code-Konvertierung."""
        # Few-shot Learning Beispiele
        examples = [
            "HLASM: DATA1 DS F\nCOBOL: 01 DATA1 PIC S9(9) COMP.",
            "HLASM: CONST DC C'HELLO'\nCOBOL: 01 CONST PIC X(5) VALUE 'HELLO'.",
            "HLASM: L R1,DATA1\nCOBOL: MOVE DATA1 TO R1."
        ]
        
        examples_text = "\n".join(examples)
        
        return f"""Convert the following HLASM (High Level Assembler) code to COBOL:

Examples:
{examples_text}

HLASM: {hlasm_code.strip()}
COBOL:"""
    
    def _extract_cobol_from_generation(self, generated_text: str, prompt: str) -> str:
        """Extrahiert COBOL-Code aus der ML-Generation."""
        # Entferne den Prompt aus der Antwort
        if prompt in generated_text:
            cobol_part = generated_text.replace(prompt, "").strip()
        else:
            cobol_part = generated_text.strip()
        
        # Bereinige die Ausgabe
        lines = cobol_part.split('\n')
        cleaned_lines = []
        
        for line in lines:
            line = line.strip()
            if line and not line.startswith('HLASM:') and not line.startswith('Examples:'):
                cleaned_lines.append(line)
        
        result = '\n'.join(cleaned_lines)
        
        # Fallback falls nichts sinnvolles generiert wurde
        if len(result.strip()) < 5:
            return f"*> ML-Konvertierung unvollständig"
        
        return result
    
    def _calculate_confidence(self, converted_code: str) -> float:
        """Berechnet Konfidenz-Score für konvertierten Code."""
        if not converted_code or converted_code.startswith("*>"):
            return 0.1
        
        # Einfache Heuristiken für COBOL-Code-Qualität
        confidence = 0.5  # Base confidence
        
        # Positive Indikatoren
        if "PIC" in converted_code:
            confidence += 0.2
        if any(kw in converted_code for kw in ["01 ", "05 ", "77 "]):
            confidence += 0.1
        if "MOVE" in converted_code or "ADD" in converted_code:
            confidence += 0.1
        if converted_code.endswith('.'):
            confidence += 0.1
        
        # Negative Indikatoren
        if len(converted_code.split()) < 3:
            confidence -= 0.2
        if "TODO" in converted_code or "FIXME" in converted_code:
            confidence -= 0.3
        
        return max(0.1, min(0.9, confidence))
    
    def batch_convert(self, statements: List[Statement]) -> List[ConversionResult]:
        """Batch-Konvertierung für bessere Performance."""
        self.logger.info(f"Starte Batch-Konvertierung für {len(statements)} Statements")
        
        results = []
        batch_start = time.time()
        
        for i, statement in enumerate(statements):
            if i % 100 == 0 and i > 0:
                self.logger.info(f"Verarbeitet: {i}/{len(statements)} Statements")
            
            result = self.convert_statement(statement)
            results.append(result)
        
        batch_time = time.time() - batch_start
        avg_time = batch_time / len(statements) if statements else 0
        
        self._conversion_stats["avg_processing_time"] = avg_time
        self.logger.info(f"Batch-Konvertierung abgeschlossen in {batch_time:.2f}s")
        
        return results
    
    def get_statistics(self) -> Dict:
        """Gibt Performance-Statistiken zurück."""
        return {
            **self._conversion_stats,
            "model_type": self.model_type.value,
            "quantization": f"{self.quantization_bits}bit",
            "device": self.device,
            "model_loaded": self._model_loaded
        }
    
    def cleanup(self) -> None:
        """Bereinigt Ressourcen."""
        if self._model is not None:
            del self._model
            self._model = None
        
        if self._pipeline is not None:
            del self._pipeline
            self._pipeline = None
            
        if torch and torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        self._model_loaded = False
        self.logger.info("ML-Ressourcen freigegeben")