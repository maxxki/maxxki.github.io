# maxxki/plugins/base.py
"""
Basis-Plugin-Interface für Converter-Plugins.
Definiert die Plugin-Architektur für erweiterte Konvertierungen.
"""

from abc import ABC, abstractmethod
from typing import Any, Optional, List, Dict
from ..core_types import Statement, StatementType


class ConverterPlugin(ABC):
    """
    Basis-Interface für alle Converter-Plugins.
    
    Plugins implementieren spezifische Konvertierungslogik für
    bestimmte HLASM-Konstrukte oder -Patterns.
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Plugin-Name für Identifikation."""
        pass
    
    @property
    @abstractmethod
    def version(self) -> str:
        """Plugin-Version."""
        pass
    
    @property
    @abstractmethod
    def supported_statement_types(self) -> List[StatementType]:
        """Liste der unterstützten Statement-Typen."""
        pass
    
    @abstractmethod
    def can_handle(self, statement: Statement) -> bool:
        """
        Prüft ob Plugin das Statement verarbeiten kann.
        
        Args:
            statement: Zu prüfendes Statement
            
        Returns:
            True wenn Plugin das Statement verarbeiten kann
        """
        pass
    
    @abstractmethod
    def convert(self, statement: Statement) -> Any:
        """
        Konvertiert Statement zu COBOL.
        
        Args:
            statement: Zu konvertierendes Statement
            
        Returns:
            Konvertierungsergebnis mit 'converted' Attribut
        """
        pass
    
    def get_priority(self) -> int:
        """
        Plugin-Priorität (höhere Werte = höhere Priorität).
        
        Returns:
            Prioritätswert (0-100)
        """
        return 50  # Default priority
    
    def cleanup(self) -> None:
        """Bereinigt Plugin-Ressourcen."""
        pass


# maxxki/plugins/datadivision.py
"""
Enhanced Data Division Converter Plugin.
Konvertiert HLASM Data Definitions zu COBOL Working-Storage.
"""

import re
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from .base import ConverterPlugin
from ..core_types import Statement, StatementType
from ..mapping_loader import MappingLoader


@dataclass
class ConversionResult:
    """Ergebnis einer Plugin-Konvertierung."""
    converted: str
    confidence_score: float
    metadata: Dict[str, Any] = None


class DataDivisionConverter(ConverterPlugin):
    """
    Erweiterte Data Division Konvertierung.
    
    Unterstützt:
    - DS/DC Statements mit allen Datentypen
    - DSECT Definitionen
    - EQU Statements
    - Komplexe Datenstrukturen
    - COBOL-Level-Nummerierung
    """
    
    @property
    def name(self) -> str:
        return "DataDivisionConverter"
    
    @property
    def version(self) -> str:
        return "2.0.0"
    
    @property
    def supported_statement_types(self) -> List[StatementType]:
        return [StatementType.DATA_DEFINITION]
    
    def __init__(self):
        self.mapping = MappingLoader().rules
        self.level_counter = 1  # COBOL level numbering
        self.current_dsect = None
        
        # Erweiterte HLASM-Datentyp-Mappings
        self.data_type_mappings = {
            'F': {'pic': 'S9(9)', 'comp': 'COMP', 'size': 4},
            'H': {'pic': 'S9(4)', 'comp': 'COMP', 'size': 2},
            'D': {'pic': 'S9(18)', 'comp': 'COMP-3', 'size': 8},
            'E': {'pic': 'S9V9(6)', 'comp': 'COMP-1', 'size': 4},
            'L': {'pic': 'S9V9(14)', 'comp': 'COMP-2', 'size': 8},
            'P': {'pic': 'S9(15)', 'comp': 'COMP-3', 'size': 8},
            'Z': {'pic': 'S9(31)', 'comp': 'COMP-5', 'size': 16},
            'B': {'pic': 'X', 'comp': '', 'size': 1},
            'C': {'pic': 'X', 'comp': '', 'size': 1},
            'X': {'pic': 'X', 'comp': '', 'size': 1},
            'A': {'pic': 'S9(15)', 'comp': 'COMP-5', 'size': 8}  # Address
        }
        
        # Regex Patterns für komplexe Parsing
        self.ds_pattern = re.compile(r'^(\w+)\s+DS\s+([0-9]*)'
                                   r'([FHDELPZBCXA])(\d*)(?:L(\d+))?', re.IGNORECASE)
        self.dc_pattern = re.compile(r'^(\w+)\s+DC\s+([0-9]*)'
                                   r'([FHDELPZBCXA])(?:L(\d+))?\'([^\']+)\'', re.IGNORECASE)
        self.dsect_pattern = re.compile(r'^(\w+)\s+DSECT', re.IGNORECASE)
        self.equ_pattern = re.compile(r'^(\w+)\s+EQU\s+(.+)', re.IGNORECASE)
        
    def can_handle(self, statement: Statement) -> bool:
        """Prüft ob Statement eine Data Definition ist."""
        if statement.stmt_type != StatementType.DATA_DEFINITION:
            return False
        
        content = statement.content.upper()
        return any(op in content for op in ['DS ', 'DC ', 'DSECT', 'EQU'])
    
    def convert(self, statement: Statement) -> ConversionResult:
        """Konvertiert Data Definition zu COBOL."""
        content = statement.content.strip()
        
        try:
            # DSECT Statement
            if 'DSECT' in content.upper():
                return self._convert_dsect(content)
            
            # EQU Statement
            elif 'EQU' in content.upper():
                return self._convert_equ(content)
            
            # DS Statement
            elif ' DS ' in content.upper():
                return self._convert_ds(content)
            
            # DC Statement
            elif ' DC ' in content.upper():
                return self._convert_dc(content)
            
            else:
                return ConversionResult(
                    converted=f"*> Unhandled data definition: {content}",
                    confidence_score=0.1
                )
                
        except Exception as e:
            return ConversionResult(
                converted=f"*> Error converting data definition: {content} ({str(e)})",
                confidence_score=0.0
            )
    
    def _convert_dsect(self, content: str) -> ConversionResult:
        """Konvertiert DSECT zu COBOL Copybook-Struktur."""
        match = self.dsect_pattern.match(content.strip())
        if not match:
            return ConversionResult(
                converted=f"*> Invalid DSECT: {content}",
                confidence_score=0.2
            )
        
        dsect_name = match.group(1)
        self.current_dsect = dsect_name
        
        converted = f"      * DSECT: {dsect_name}\n       01  {dsect_name}-STRUCTURE."
        
        return ConversionResult(
            converted=converted,
            confidence_score=0.9,
            metadata={'dsect_name': dsect_name}
        )
    
    def _convert_equ(self, content: str) -> ConversionResult:
        """Konvertiert EQU zu COBOL 77-Level oder Konstante."""
        match = self.equ_pattern.match(content.strip())
        if not match:
            return ConversionResult(
                converted=f"*> Invalid EQU: {content}",
                confidence_score=0.2
            )
        
        symbol = match.group(1)
        value = match.group(2).strip()
        
        # Numeric constant
        if value.isdigit():
            converted = f"       77  {symbol:<30} PIC 9(9) VALUE {value}."
            confidence = 0.95
        # Character constant
        elif value.startswith("'") and value.endswith("'"):
            char_value = value[1:-1]
            length = len(char_value)
            converted = f"       77  {symbol:<30} PIC X({length}) VALUE {value}."
            confidence = 0.95
        # Expression or address
        else:
            converted = f"      * EQU: {symbol} = {value}\n       77  {symbol:<30} PIC S9(9) COMP VALUE ZERO."
            confidence = 0.7
        
        return ConversionResult(
            converted=converted,
            confidence_score=confidence,
            metadata={'symbol': symbol, 'value': value}
        )
    
    def _convert_ds(self, content: str) -> ConversionResult:
        """Konvertiert DS (Define Storage) zu COBOL Data Definition."""
        match = self.ds_pattern.match(content.strip())
        if not match:
            return ConversionResult(
                converted=f"*> Invalid DS: {content}",
                confidence_score=0.2
            )
        
        name = match.group(1)
        duplication = match.group(2) or "1"
        data_type = match.group(3).upper()
        type_modifier = match.group(4) or ""
        length_modifier = match.group(5)
        
        # Get COBOL mapping
        if data_type not in self.data_type_mappings:
            return ConversionResult(
                converted=f"*> Unsupported data type {data_type}: {content}",
                confidence_score=0.3
            )
        
        mapping = self.data_type_mappings[data_type]
        
        # Calculate level number
        level = self._get_cobol_level()
        
        # Build COBOL definition
        pic_clause = self._build_pic_clause(data_type, type_modifier, length_modifier, mapping)
        
        if int(duplication) > 1:
            converted = f"       {level:02d}  {name:<30} OCCURS {duplication} TIMES\n" + \
                       f"                                    {pic_clause}."
        else:
            converted = f"       {level:02d}  {name:<30} {pic_clause}."
        
        return ConversionResult(
            converted=converted,
            confidence_score=0.9,
            metadata={
                'name': name,
                'data_type': data_type,
                'duplication': duplication,
                'cobol_level': level
            }
        )
    
    def _convert_dc(self, content: str) -> ConversionResult:
        """Konvertiert DC (Define Constant) zu COBOL Value Clause."""
        match = self.dc_pattern.match(content.strip())
        if not match:
            return ConversionResult(
                converted=f"*> Invalid DC: {content}",
                confidence_score=0.2
            )
        
        name = match.group(1)
        duplication = match.group(2) or "1"
        data_type = match.group(3).upper()
        length_modifier = match.group(4)
        value = match.group(5)
        
        if data_type not in self.data_type_mappings:
            return ConversionResult(
                converted=f"*> Unsupported data type {data_type}: {content}",
                confidence_score=0.3
            )
        
        mapping = self.data_type_mappings[data_type]
        level = self._get_cobol_level()
        
        # Build PIC clause and VALUE
        pic_clause = self._build_pic_clause(data_type, "", length_modifier, mapping, value)
        value_clause = self._build_value_clause(data_type, value)
        
        if int(duplication) > 1:
            converted = f"       {level:02d}  {name:<30} OCCURS {duplication} TIMES\n" + \
                       f"                                    {pic_clause}\n" + \
                       f"                                    {value_clause}."
        else:
            converted = f"       {level:02d}  {name:<30} {pic_clause}\n" + \
                       f"                                    {value_clause}."
        
        return ConversionResult(
            converted=converted,
            confidence_score=0.9,
            metadata={
                'name': name,
                'data_type': data_type,
                'value': value,
                'cobol_level': level
            }
        )
    
    def _build_pic_clause(self, data_type: str, type_modifier: str, 
                         length_modifier: Optional[str], mapping: Dict, 
                         value: Optional[str] = None) -> str:
        """Erstellt COBOL PIC Clause."""
        pic = mapping['pic']
        comp = mapping['comp']
        
        # Character data with length
        if data_type in ['C', 'X', 'B']:
            if length_modifier:
                length = int(length_modifier)
            elif value:
                length = len(value)
            elif type_modifier:
                length = int(type_modifier)
            else:
                length = 1
            
            pic_clause = f"PIC X({length})"
        
        # Numeric data with precision
        elif data_type == 'P':  # Packed decimal
            if type_modifier:
                precision = int(type_modifier)
                pic_clause = f"PIC S9({precision}) {comp}"
            else:
                pic_clause = f"PIC {pic} {comp}"
        
        # Standard numeric
        else:
            if comp:
                pic_clause = f"PIC {pic} {comp}"
            else:
                pic_clause = f"PIC {pic}"
        
        return pic_clause
    
    def _build_value_clause(self, data_type: str, value: str) -> str:
        """Erstellt COBOL VALUE Clause."""
        if data_type in ['C', 'X', 'B']:
            # Character value
            return f"VALUE '{value}'"
        elif data_type in ['F', 'H', 'P']:
            # Numeric value
            if value.isdigit() or (value.startswith('-') and value[1:].isdigit()):
                return f"VALUE {value}"
            else:
                # Hex or complex value
                return f"VALUE ZERO  *> Original: {value}"
        else:
            return f"VALUE ZERO  *> Original: {value}"
    
    def _get_cobol_level(self) -> int:
        """Bestimmt COBOL Level Number."""
        if self.current_dsect:
            return 5  # Sub-level in DSECT
        else:
            return 1  # Top level
    
    def get_priority(self) -> int:
        """Hohe Priorität für Data Definitions."""
        return 80


# maxxki/plugins/instructions.py
"""
Instruction Converter Plugin.
Konvertiert HLASM Machine Instructions zu COBOL Procedure Division Code.
"""

from typing import Dict, List, Optional, Any
import re

from .base import ConverterPlugin
from ..core_types import Statement, StatementType


class InstructionConverter(ConverterPlugin):
    """
    Konvertiert HLASM Instructions zu COBOL Procedure Division.
    
    Unterstützt:
    - Arithmetic Instructions (A, S, M, D)
    - Load/Store Instructions (L, ST)
    - Compare Instructions (C, CL)
    - Branch Instructions (B, BC, BE, etc.)
    - Logical Instructions (N, O, X)
    """
    
    @property
    def name(self) -> str:
        return "InstructionConverter"
    
    @property
    def version(self) -> str:
        return "1.5.0"
    
    @property
    def supported_statement_types(self) -> List[StatementType]:
        return [StatementType.INSTRUCTION]
    
    def __init__(self):
        # Instruction mapping to COBOL
        self.instruction_mappings = {
            # Arithmetic
            'A': self._convert_add,
            'AH': self._convert_add,
            'AR': self._convert_add,
            'S': self._convert_subtract,
            'SH': self._convert_subtract,
            'SR': self._convert_subtract,
            'M': self._convert_multiply,
            'MH': self._convert_multiply,
            'MR': self._convert_multiply,
            'D': self._convert_divide,
            'DR': self._convert_divide,
            
            # Load/Store
            'L': self._convert_load,
            'LH': self._convert_load,
            'LA': self._convert_load_address,
            'LR': self._convert_load_register,
            'ST': self._convert_store,
            'STH': self._convert_store,
            
            # Compare
            'C': self._convert_compare,
            'CH': self._convert_compare,
            'CL': self._convert_compare,
            'CR': self._convert_compare,
            
            # Branch
            'B': self._convert_branch,
            'BC': self._convert_branch_condition,
            'BE': self._convert_branch_equal,
            'BNE': self._convert_branch_not_equal,
            'BH': self._convert_branch_high,
            'BL': self._convert_branch_low,
            'BZ': self._convert_branch_zero,
            'BNZ': self._convert_branch_not_zero,
            
            # Logical
            'N': self._convert_and,
            'NR': self._convert_and,
            'O': self._convert_or,
            'OR': self._convert_or,
            'X': self._convert_xor,
            'XR': self._convert_xor,
        }
        
        # Register mappings
        self.register_mappings = {
            'R0': 'WS-REG-0', 'R1': 'WS-REG-1', 'R2': 'WS-REG-2', 'R3': 'WS-REG-3',
            'R4': 'WS-REG-4', 'R5': 'WS-REG-5', 'R6': 'WS-REG-6',