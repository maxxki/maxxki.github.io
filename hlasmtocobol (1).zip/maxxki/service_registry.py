# maxxki/service_registry.py
"""
Enterprise Service Registry für Dependency Injection mit ML-Unterstützung.
Singleton Pattern mit lazy loading und konfigurierbare Services.
"""

import logging
import os
from typing import Any, Dict, Type, Optional, Callable
from pathlib import Path
import yaml


class ServiceRegistry:
    """
    Zentraler Service Registry für alle maxxki-Komponenten.
    Implementiert Singleton Pattern mit Thread-Safety.
    """
    
    _instance = None
    _services: Dict[str, Any] = {}
    _factories: Dict[str, Callable] = {}
    _config: Dict[str, Any] = {}
    _initialized = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def initialize(cls, config_path: Optional[str] = None) -> None:
        """
        Initialisiert den Service Registry mit Konfiguration.
        
        Args:
            config_path: Pfad zur Konfigurationsdatei (optional)
        """
        if cls._initialized:
            return
            
        instance = cls()
        instance._load_config(config_path)
        instance._register_default_services()
        cls._initialized = True
        
        logging.getLogger(__name__).info("ServiceRegistry initialisiert")
    
    def _load_config(self, config_path: Optional[str]) -> None:
        """Lädt Konfiguration aus YAML-Datei."""
        if config_path is None:
            config_path = os.getenv("MAXXKI_CONFIG", "config/services.yml")
        
        config_file = Path(config_path)
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                self._config = yaml.safe_load(f) or {}
        else:
            # Default-Konfiguration
            self._config = {
                "ml": {
                    "enabled": True,
                    "model_type": "Salesforce/codet5p-770m",
                    "quantization_bits": 8,
                    "max_memory_gb": 16.0,
                    "cache_dir": "./models"
                },
                "parser": {
                    "type": "enhanced",
                    "max_line_length": 80,
                    "strict_syntax": False
                },
                "logging": {
                    "level": "INFO",
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                }
            }
    
    def _register_default_services(self) -> None:
        """Registriert Standard-Services."""
        # Parser Factory
        self.register_factory("parser", self._create_parser)
        
        # ML Model Factory (nur wenn aktiviert)
        if self._config.get("ml", {}).get("enabled", True):
            self.register_factory("ml_model", self._create_ml_model)
        
        # Mapping Loader Factory
        self.register_factory("mapping_loader", self._create_mapping_loader)
        
        # Logger Factory
        self.register_factory("logger", self._create_logger)
    
    def _create_parser(self) -> Any:
        """Factory für Parser-Erstellung."""
        from .parser import Parser, EnhancedParser
        
        parser_config = self._config.get("parser", {})
        parser_type = parser_config.get("type", "basic")
        
        if parser_type == "enhanced":
            return EnhancedParser(
                max_line_length=parser_config.get("max_line_length", 80),
                strict_syntax=parser_config.get("strict_syntax", False)
            )
        else:
            return Parser()
    
    def _create_ml_model(self) -> Any:
        """Factory für ML-Model-Erstellung."""
        from .ml.local_converter import LocalMLConverter, ModelType
        
        ml_config = self._config.get("ml", {})
        
        # Model Type String zu Enum konvertieren
        model_name = ml_config.get("model_type", "Salesforce/codet5p-770m")
        model_type = ModelType.CODET5_PLUS  # Default
        
        for mt in ModelType:
            if mt.value == model_name:
                model_type = mt
                break
        
        return LocalMLConverter(
            model_type=model_type,
            quantization_bits=ml_config.get("quantization_bits", 8),
            max_memory_gb=ml_config.get("max_memory_gb", 16.0),
            cache_dir=ml_config.get("cache_dir", "./models")
        )
    
    def _create_mapping_loader(self) -> Any:
        """Factory für MappingLoader-Erstellung."""
        from .mapping_loader import MappingLoader
        return MappingLoader()
    
    def _create_logger(self) -> logging.Logger:
        """Factory für Logger-Erstellung."""
        log_config = self._config.get("logging", {})
        
        # Root Logger konfigurieren
        logging.basicConfig(
            level=getattr(logging, log_config.get("level", "INFO")),
            format=log_config.get("format", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )
        
        return logging.getLogger("maxxki")
    
    @classmethod
    def register(cls, name: str, service: Any) -> None:
        """
        Registriert einen Service direkt.
        
        Args:
            name: Service-Name
            service: Service-Instanz
        """
        cls._services[name] = service
    
    @classmethod
    def register_factory(cls, name: str, factory: Callable) -> None:
        """
        Registriert eine Factory-Funktion für lazy loading.
        
        Args:
            name: Service-Name
            factory: Factory-Funktion
        """
        cls._factories[name] = factory
    
    @classmethod
    def get(cls, name: str) -> Any:
        """
        Holt einen Service (mit lazy loading).
        
        Args:
            name: Service-Name
            
        Returns:
            Service-Instanz
            
        Raises:
            KeyError: Wenn Service nicht registriert
        """
        if not cls._initialized:
            cls.initialize()
        
        # Bereits erstellter Service
        if name in cls._services:
            return cls._services[name]
        
        # Factory verfügbar?
        if name in cls._factories:
            service = cls._factories[name]()
            cls._services[name] = service
            return service
        
        raise KeyError(f"Service '{name}' nicht registriert")
    
    @classmethod
    def has(cls, name: str) -> bool:
        """
        Prüft ob ein Service verfügbar ist.
        
        Args:
            name: Service-Name
            
        Returns:
            True wenn Service verfügbar
        """
        return name in cls._services or name in cls._factories
    
    @classmethod
    def get_config(cls, key: str = None) -> Any:
        """
        Holt Konfigurationswerte.
        
        Args:
            key: Konfigurationsschlüssel (optional)
            
        Returns:
            Konfigurationswert oder gesamte Konfiguration
        """
        if not cls._initialized:
            cls.initialize()
        
        if key is None:
            return cls._config
        
        # Nested key support (z.B. "ml.model_type")
        keys = key.split('.')
        value = cls._config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return None
        
        return value
    
    @classmethod
    def clear(cls) -> None:
        """Bereinigt alle Services (für Tests)."""
        # Cleanup ML resources
        if "ml_model" in cls._services:
            ml_model = cls._services["ml_model"]
            if hasattr(ml_model, 'cleanup'):
                ml_model.cleanup()
        
        cls._services.clear()
        cls._factories.clear()
        cls._config.clear()
        cls._initialized = False


# Enhanced Parser Implementation
# maxxki/parser.py (erweitert)
"""
Erweiterte Parser-Implementierung mit verbesserter HLASM-Syntax-Unterstützung.
"""

import re
from typing import List, Optional, Dict, Tuple
from dataclasses import dataclass
from enum import Enum

from .core_types import Statement, StatementType


class InstructionType(Enum):
    """HLASM Instruktions-Typen."""
    DATA_DEFINITION = "data_def"
    MACHINE_INSTRUCTION = "machine"
    ASSEMBLER_DIRECTIVE = "directive"
    MACRO_CALL = "macro_call"
    MACRO_DEFINITION = "macro_def"
    COMMENT = "comment"


@dataclass
class ParsedInstruction:
    """Detaillierte Instruktions-Information."""
    label: Optional[str]
    operation: str
    operands: List[str] 
    comment: Optional[str]
    line_number: int
    instruction_type: InstructionType


class EnhancedParser:
    """
    Erweiterte HLASM-Parser mit verbesserter Syntax-Erkennung.
    
    Features:
    - Vollständige HLASM-Syntax-Unterstützung
    - Macro-Erkennung und -Verarbeitung
    - Bedingte Assemblierung
    - Erweiterte Operanden-Parsing
    - Error Recovery
    """
    
    def