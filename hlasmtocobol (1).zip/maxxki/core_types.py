# maxxki/core_types.py
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

class StatementType(Enum):
    DATA_DEFINITION = "data_definition"
    MACHINE_INSTRUCTION = "machine_instruction"
    ASSEMBLER_DIRECTIVE = "assembler_directive"
    MACRO = "macro"
    COMMENT = "comment"
    UNKNOWN = "unknown"

@dataclass
class Statement:
    content: str
    stmt_type: StatementType = StatementType.UNKNOWN
    line_no: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ConversionResult:
    converted: str
    confidence_score: float = 0.0
    conversion_method: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ConversionReport:
    results: List[ConversionResult]
    success_rate: float = 0.0
    stats: Dict[str, Any] = field(default_factory=dict)