# tests/test_plugins.py
from maxxki.plugins.datadivision import DataDivisionConverter
from maxxki.core_types import Statement, StatementType

def test_data_division_converter():
    plugin = DataDivisionConverter()
    stmt = Statement(content="RESULT DS F", stmt_type=StatementType.DATA_DEFINITION)
    result = plugin.convert(stmt)
    assert "PIC" in result.converted or result.converted.startswith("MOVE"), \
        "Converter should generate some COBOL-like output"