# tests/test_mapping_loader.py
from maxxki.mapping_loader import MappingLoader

def test_mapping_loader():
    loader = MappingLoader()
    rules = loader.rules
    assert "data_definitions" in rules
    assert "DS" in rules["data_definitions"]
    assert rules["data_definitions"]["DS"]["F"].startswith("PIC")