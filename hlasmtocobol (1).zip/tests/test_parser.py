# tests/test_parser.py
from maxxki.parser import Parser

def test_basic_parse():
    parser = Parser()
    code = "RESULT DS F"
    stmts = parser.parse(code)
    assert stmts, "Parser should return at least one statement"
    assert stmts[0].content.startswith("RESULT")