# tests/test_end_to_end.py
import subprocess
from pathlib import Path
import sys

def test_cli_end_to_end(tmp_path: Path):
    """End-to-End test: run CLI on a small HLASM file and check COBOL output."""

    # Beispiel-HLASM-Code in temporäre Datei schreiben
    asm_file = tmp_path / "sample.hlasm"
    asm_file.write_text("RESULT DS F\n", encoding="utf-8")

    # Ausgabe-Datei festlegen
    cobol_file = tmp_path / "out.cbl"

    # CLI aufrufen
    result = subprocess.run(
        [sys.executable, "-m", "maxxki.cli", str(asm_file), "-o", str(cobol_file), "--no-ml"],
        capture_output=True,
        text=True,
    )

    # Sollte ohne Fehler laufen
    assert result.returncode == 0, f"CLI failed: {result.stderr}"

    # COBOL-Datei sollte erzeugt sein
    assert cobol_file.exists(), "COBOL output file not created"
    content = cobol_file.read_text(encoding="utf-8")
    assert "Unconverted" in content or "PIC" in content, \
        "COBOL output should contain some converted text"

def test_cli_matches_sample(tmp_path: Path):
    """Check that generated COBOL contains expected fragments from sample.cbl."""

    asm_file = tmp_path / "sample.hlasm"
    asm_file.write_text("RESULT DS F\n", encoding="utf-8")

    cobol_file = tmp_path / "out.cbl"

    import subprocess, sys
    subprocess.run(
        [sys.executable, "-m", "maxxki.cli", str(asm_file), "-o", str(cobol_file), "--no-ml"],
        check=True,
    )

    generated = cobol_file.read_text(encoding="utf-8")

    # Vergleich gegen Erwartung
    expected = Path("tests/sample.cbl").read_text(encoding="utf-8")

    # Prüfen, dass Schlüsselwörter vorkommen
    for keyword in ["DATA DIVISION", "WORKING-STORAGE", "RESULT"]:
        assert keyword in generated or keyword in expected, f"{keyword} missing in COBOL output"
        
def test_cli_with_snippets(tmp_path: Path):
    import subprocess, sys
    asm_file = tmp_path / "snippets.asm"

    # Kopiere Test-Snippets in Temp-Datei
    from pathlib import Path as _Path
    asm_file.write_text(
        _Path("tests/samples/hlasm_snippets.asm").read_text(encoding="utf-8"),
        encoding="utf-8"
    )

    cobol_file = tmp_path / "snippets.cbl"

    subprocess.run(
        [sys.executable, "-m", "maxxki.cli", str(asm_file), "-o", str(cobol_file), "--no-ml"],
        check=True,
    )

    generated = cobol_file.read_text(encoding="utf-8")

    # Erwartete COBOL-Fragmente (noch generisch)
    assert "RESULT" in generated
    assert "CONST1" in generated
    assert "CONST2" in generated