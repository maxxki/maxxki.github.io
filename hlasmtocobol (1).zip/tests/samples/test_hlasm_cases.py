# tests/test_hlasm_cases.py
from maxxki.parser import Parser
from maxxki.core_types import StatementType

def test_parse_data_definitions():
    parser = Parser()
    code = "RESULT DS F\nCONST1 DC F'42'\nCONST2 DC C'HELLO'\n"
    stmts = parser.parse(code)
    types = [s.stmt_type for s in stmts]
    assert StatementType.DATA_DEFINITION in types, "DATA DEFINITION not recognized"

def test_parse_macro():
    parser = Parser()
    code = "MYMACRO MACRO\n&ARG1 DS F\nMEND\n"
    stmts = parser.parse(code)
    contents = [s.content for s in stmts]
    assert any("MACRO" in c for c in contents), "MACRO not recognized"
    assert any("MEND" in c for c in contents), "MEND not recognized"